# BugBountyTUI

A multipurpose Go TUI for bug bounty hunting, built around Charm's Bubble Tea + Lip Gloss stack.

This version upgrades the project from a scheduler with logs into a small operator console:

- dependency-aware parallel workflow execution
- run graph/status view with per-node states and durations
- persistent run history under `workspace/history/`
- artifact browser with inline preview inside the TUI
- bootstrap manager showing runnable vs missing tools before execution
- dynamic categories derived from the configured tool registry
- a much larger bug bounty tooling catalog, including ProjectDiscovery tools, Jaeles, and Kiterunner
- a bootstrap manager with PATH checks, version detection, install hints, and missing/partial badges

## Core capabilities

- target domain input in the TUI
- per-tool toggles and editable arguments
- editable output paths, shell commands, dependencies, and artifact gates
- config persisted to `config/config.yaml`
- live command log stream in the bottom panel
- per-category aggregate outputs such as:
  - `workspace/subdomains/all_subdomains.txt`
  - `workspace/probe/all_probe.txt`
  - `workspace/urls/all_urls.txt`
  - `workspace/params/all_params.txt`
  - `workspace/js/all_js.txt`
  - `workspace/vulns/all_vulns.txt`

## Current categories

- `subdomains`
- `dns`
- `probe`
- `urls`
- `params`
- `content`
- `js`
- `secrets`
- `vulns`
- `takeover`
- `screenshots`
- `intel`
- `api`

## Included tool coverage

### Subdomains
- crt.sh (built-in)
- assetfinder
- subfinder
- chaos-client
- amass enum
- findomain
- github-subdomains
- shuffledns

### DNS / validation
- dnsx
- cdncheck

### Probing / service confirmation
- httpx
- httprobe
- naabu
- tlsx

### URL gathering / crawling
- urlfinder
- gau
- waybackurls
- katana
- hakrawler

### Parameters / candidate generation
- paramspider
- arjun
- gf xss
- gf sqli
- gf ssrf
- qsreplace

### Content discovery
- ffuf
- feroxbuster
- dirsearch

### JavaScript / client-side recon
- subjs
- jsubfinder
- cariddi
- linkfinder

### Web testing / vuln passes
- nuclei
- jaeles
- dalfox
- kxss
- corsy
- sqlmap
- xsrfprobe
- xsstrike

### Other useful categories
- takeover: `subzy`
- screenshots: `gowitness`
- intel: `uncover`, `asnmap`
- api: `kiterunner`

Most aggressive or environment-specific tools are disabled by default on purpose. That is not cowardice; that is how you avoid accidentally turning recon into noisy chaos.

## Layout

- Left: dynamic categories + tool list
- Center: target metadata and one of:
  - run graph/status
  - artifact browser and preview
  - run history
  - bootstrap manager
  - help
- Right: selected tool fields and latest run status
- Bottom: live log stream

## Key bindings

- `Tab` / `Shift+Tab`: move focus between target, tools, center, fields
- `Left` / `Right`: switch category when tool panel is focused
- `Up` / `Down`: navigate
- `Space`: toggle `Enabled` on the selected field
- `Enter`: edit selected field
- `Ctrl+S`: save config
- `g`: graph/status view
- `a`: artifact browser
- `H`: run history
- `b`: bootstrap manager
- `B`: refresh bootstrap checks
- `?`: help
- `[` / `]`: cycle center views
- `r`: run enabled tools in active category
- `R`: run all enabled tools
- `x`: run selected tool
- `Esc`: cancel current run
- `q`: quit

## Workflow fields

Each tool supports editable fields in the TUI:

- `Enabled`
- `Description`
- `Mode`
- `Bin`
- `Args`
- `Shell`
- `Output`
- `DependsOn`
- `RequiresFiles`

## Template variables

These placeholders can be used in args, shell commands, output paths, and file gates:

- `{{target}}`
- `{{domain}}`
- `{{workspace}}`
- `{{output}}`
- `{{history_dir}}`
- `{{subdomains_file}}`
- `{{dns_file}}`
- `{{alive_file}}`
- `{{probe_file}}`
- `{{ports_file}}`
- `{{urls_file}}`
- `{{params_file}}`
- `{{content_file}}`
- `{{js_file}}`
- `{{secrets_file}}`
- `{{vulns_file}}`
- `{{screens_file}}`
- `{{intel_file}}`
- `{{api_file}}`
- `{{base_url}}`

## History and artifacts

Completed runs are saved as JSON summaries in:

```text
workspace/history/run-YYYYMMDDTHHMMSSZ.json
```

The artifact browser indexes files under the workspace and previews the selected file inline. That makes post-run inspection less annoying than spelunking directories manually like it is 2009.

## Bootstrap manager

The bootstrap manager is the missing sanity layer between a tool registry and a usable operator console. It does three things:

- checks whether the inferred runtime binaries for each tool are present in `PATH`
- probes a version string when possible
- shows an install hint when something is missing

Badge meanings in the tool list:

- `OK`: inferred runtime deps are present
- `MISS`: required dependency is missing, so the runner will skip the tool
- `PART`: some inferred shell dependencies are present, some are missing
- `BI`: builtin step, no local binary required

This is intentionally conservative. Shell pipelines are inferred heuristically, so `PART` means exactly what it says: the TUI found enough to be suspicious, not enough to trust blindly.

## Build

### Install module dependencies

```bash
make deps
```

Or manually:

```bash
go get charm.land/bubbletea/v2
go get charm.land/bubbles/v2
go get charm.land/lipgloss/v2
go get gopkg.in/yaml.v3
go mod tidy
```

### Run

```bash
go run ./cmd/bugbountytui -config config/config.yaml
```

## External tools expected in PATH

Install the subset you actually want. The registry includes many tools, but the TUI is designed so you can enable only what makes sense for your environment and scope. Missing binaries are now surfaced directly in the TUI, and the runner will skip tools that fail the local bootstrap preflight instead of faceplanting into a bad exec.

Examples:

- assetfinder
- subfinder
- chaos-client (`chaos`)
- amass
- findomain
- dnsx
- cdncheck
- httpx
- httprobe
- naabu
- tlsx
- urlfinder
- gau
- waybackurls
- katana
- hakrawler
- paramspider
- arjun
- gf
- qsreplace
- ffuf
- feroxbuster
- dirsearch
- subjs
- jsubfinder
- cariddi
- nuclei
- jaeles
- dalfox
- kxss
- corsy
- sqlmap
- subzy
- gowitness
- uncover
- asnmap
- kiterunner (`kr`)

## Important security note

Do **not** hardcode API keys into source control or config files you plan to share. Use environment variables via `.env` or your shell profile, and point YAML values at `${ENV_VAR_NAME}` placeholders.

If you pasted real keys into chat, docs, commits, or screenshots, rotate them.

## Notes

- Some tools in this ecosystem have version-specific flags. Edit args in the TUI or config file to match your local install.
- Some tools like `shuffledns`, `linkfinder`, `gowitness`, and `kiterunner` intentionally use placeholders or locally edited paths because installations differ wildly.
- This project is still a starter, but it now behaves more like a real local bug bounty workbench than a fancy wrapper around `os/exec`.
