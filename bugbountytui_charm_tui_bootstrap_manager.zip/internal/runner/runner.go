package runner

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"bugbountytui/internal/bootstrap"
	"bugbountytui/internal/config"
)

type EventType string

const (
	EventPlan     EventType = "plan"
	EventLog      EventType = "log"
	EventStarted  EventType = "started"
	EventFinished EventType = "finished"
	EventError    EventType = "error"
	EventSkipped  EventType = "skipped"
	EventWaiting  EventType = "waiting"
	EventDone     EventType = "done"
)

type ToolStatus struct {
	Tool          string
	Category      string
	State         string
	DependsOn     []string
	RequiresFiles []string
	StartedAt     time.Time
	FinishedAt    time.Time
	Duration      time.Duration
	ExitCode      int
	OutputPath    string
	ArtifactCount int
	Error         string
}

type Event struct {
	Type EventType
	Tool string
	Text string
	Err  error
	Node *ToolStatus
}

type RunMode string

const (
	RunSelected RunMode = "selected"
	RunCategory RunMode = "category"
	RunAll      RunMode = "all"
)

type Request struct {
	Mode          RunMode
	SelectedTool  string
	Category      string
	Config        *config.App
	ConfigPath    string
	ExecutionRoot string
}

type crtShEntry struct {
	NameValue string `json:"name_value"`
}

type toolState struct {
	Tool           config.Tool
	PendingDeps    map[string]struct{}
	ExternalDeps   []string
	Started        bool
	Finished       bool
	Failed         bool
	Skipped        bool
	FailureReason  string
	WaitingReason  string
	WaitingEmitted string
	Status         ToolStatus
}

type runResult struct {
	ToolName      string
	Category      string
	OutputPath    string
	ArtifactCount int
	ExitCode      int
	Err           error
}

func Run(ctx context.Context, req Request, ch chan<- Event) {
	defer close(ch)
	cfg := req.Config
	emit(ch, Event{Type: EventLog, Text: fmt.Sprintf("workspace: %s", cfg.Workspace)})
	emit(ch, Event{Type: EventLog, Text: fmt.Sprintf("target: %s", cfg.Target.Domain)})
	emit(ch, Event{Type: EventLog, Text: fmt.Sprintf("max parallel: %d", cfg.Runner.MaxParallel)})

	if err := os.MkdirAll(cfg.Workspace, 0o755); err != nil {
		emit(ch, Event{Type: EventError, Text: "create workspace failed", Err: err})
		emit(ch, Event{Type: EventDone, Text: "run aborted"})
		return
	}

	selected := selectTools(cfg.Tools, req.Mode, req.Category, req.SelectedTool)
	if len(selected) == 0 {
		emit(ch, Event{Type: EventError, Text: "no matching enabled tools found", Err: errors.New("empty run selection")})
		emit(ch, Event{Type: EventDone, Text: "nothing to run"})
		return
	}

	plan, order, err := buildPlan(selected)
	if err != nil {
		emit(ch, Event{Type: EventError, Text: "invalid execution plan", Err: err})
		emit(ch, Event{Type: EventDone, Text: "run aborted"})
		return
	}

	for _, name := range order {
		state := plan[name]
		vars := templateVars(cfg, state.Tool)
		requiresFiles := make([]string, 0, len(state.Tool.RequiresFiles))
		for _, required := range state.Tool.RequiresFiles {
			requiresFiles = append(requiresFiles, filepath.Clean(expandTemplate(required, vars)))
		}
		state.Status = ToolStatus{
			Tool:          state.Tool.Name,
			Category:      state.Tool.Category,
			State:         "queued",
			DependsOn:     append([]string(nil), state.Tool.DependsOn...),
			RequiresFiles: requiresFiles,
			OutputPath:    filepath.Clean(expandTemplate(filepath.Join(cfg.Workspace, state.Tool.Output), vars)),
		}
		emit(ch, Event{Type: EventPlan, Tool: state.Tool.Name, Text: "planned", Node: cloneStatus(state.Status)})
		if len(state.ExternalDeps) > 0 {
			emit(ch, Event{Type: EventLog, Tool: name, Text: fmt.Sprintf("external dependencies not in active run: %s", strings.Join(state.ExternalDeps, ", "))})
		}
		if reason, missing := bootstrap.MissingReason(state.Tool); missing {
			state.Skipped = true
			state.FailureReason = reason
			state.Status.State = "skipped"
			state.Status.Error = reason
			state.Status.FinishedAt = time.Now()
			emit(ch, Event{Type: EventSkipped, Tool: state.Tool.Name, Text: reason, Node: cloneStatus(state.Status)})
		}
	}

	resultCh := make(chan runResult, len(plan))
	active := 0
	failed := 0
	stopScheduling := false

	for terminalCount(plan) < len(plan) {
		if ctx.Err() != nil && !stopScheduling {
			emit(ch, Event{Type: EventError, Text: "run cancelled", Err: ctx.Err()})
			markRemainderSkipped(plan, ch, "cancelled")
			stopScheduling = true
		}

		startedThisTick := 0
		if !stopScheduling {
			for _, name := range order {
				if active >= cfg.Runner.MaxParallel {
					break
				}
				state := plan[name]
				if state.Started || state.Finished || state.Skipped || state.Failed {
					continue
				}
				if reason, blocked := blockedByFailure(plan, state); blocked {
					state.Skipped = true
					state.FailureReason = reason
					state.Status.State = "skipped"
					state.Status.Error = reason
					state.Status.FinishedAt = time.Now()
					emit(ch, Event{Type: EventSkipped, Tool: state.Tool.Name, Text: reason, Node: cloneStatus(state.Status)})
					continue
				}
				if len(state.PendingDeps) > 0 {
					reason := fmt.Sprintf("waiting on dependencies: %s", joinPendingDeps(state.PendingDeps))
					maybeEmitWaiting(ch, state, reason)
					continue
				}
				if reason, waiting := waitingOnFiles(cfg, state.Tool); waiting {
					maybeEmitWaiting(ch, state, reason)
					continue
				}

				state.Started = true
				state.WaitingReason = ""
				state.WaitingEmitted = ""
				state.Status.State = "running"
				state.Status.StartedAt = time.Now()
				state.Status.FinishedAt = time.Time{}
				state.Status.Duration = 0
				state.Status.ExitCode = 0
				state.Status.Error = ""
				active++
				startedThisTick++
				emit(ch, Event{Type: EventStarted, Tool: state.Tool.Name, Text: fmt.Sprintf("starting %s", state.Tool.Name), Node: cloneStatus(state.Status)})

				go func(tool config.Tool) {
					resultCh <- runTool(ctx, cfg, tool, ch)
				}(state.Tool)
			}
		}

		if startedThisTick == 0 {
			if active == 0 {
				markDeadlocked(plan, cfg, ch)
				break
			}
		} else {
			continue
		}

		select {
		case <-ctx.Done():
			if !stopScheduling {
				emit(ch, Event{Type: EventError, Text: "run cancelled", Err: ctx.Err()})
				markRemainderSkipped(plan, ch, "cancelled")
				stopScheduling = true
			}
		case res := <-resultCh:
			active--
			state := plan[res.ToolName]
			state.Status.OutputPath = res.OutputPath
			state.Status.ArtifactCount = res.ArtifactCount
			state.Status.ExitCode = res.ExitCode
			state.Status.FinishedAt = time.Now()
			if !state.Status.StartedAt.IsZero() {
				state.Status.Duration = state.Status.FinishedAt.Sub(state.Status.StartedAt)
			}
			if res.Err != nil {
				state.Failed = true
				failed++
				state.Status.State = "failed"
				state.Status.Error = res.Err.Error()
				emit(ch, Event{Type: EventError, Tool: res.ToolName, Text: fmt.Sprintf("%s failed", res.ToolName), Err: res.Err, Node: cloneStatus(state.Status)})
				if cfg.Runner.FailFast && !stopScheduling {
					emit(ch, Event{Type: EventError, Text: "fail-fast triggered", Err: res.Err})
					markRemainderSkipped(plan, ch, "stopped by fail-fast")
					stopScheduling = true
				}
			} else {
				state.Finished = true
				state.Status.State = "finished"
				emit(ch, Event{Type: EventFinished, Tool: res.ToolName, Text: fmt.Sprintf("finished %s", res.ToolName), Node: cloneStatus(state.Status)})
			}

			mergeCategoryAggregate(cfg.Workspace, res.Category)
			for _, other := range plan {
				delete(other.PendingDeps, res.ToolName)
			}
		}
	}

	mergeAllCategories(cfg.Workspace)
	emit(ch, Event{Type: EventDone, Text: fmt.Sprintf("run complete: %d finished, %d failed, %d skipped", countStates(plan, func(state *toolState) bool { return state.Finished }), failed, countStates(plan, func(state *toolState) bool { return state.Skipped }))})
}

func buildPlan(tools []config.Tool) (map[string]*toolState, []string, error) {
	plan := make(map[string]*toolState, len(tools))
	order := make([]string, 0, len(tools))
	for _, tool := range tools {
		if _, exists := plan[tool.Name]; exists {
			return nil, nil, fmt.Errorf("duplicate selected tool: %s", tool.Name)
		}
		plan[tool.Name] = &toolState{
			Tool:        tool,
			PendingDeps: make(map[string]struct{}),
		}
		order = append(order, tool.Name)
	}

	for _, state := range plan {
		for _, dep := range state.Tool.DependsOn {
			dep = strings.TrimSpace(dep)
			if dep == "" {
				continue
			}
			if dep == state.Tool.Name {
				return nil, nil, fmt.Errorf("tool %s depends on itself", state.Tool.Name)
			}
			if _, ok := plan[dep]; !ok {
				state.ExternalDeps = append(state.ExternalDeps, dep)
				continue
			}
			state.PendingDeps[dep] = struct{}{}
		}
	}

	visited := make(map[string]int, len(plan))
	var visit func(string) error
	visit = func(name string) error {
		switch visited[name] {
		case 1:
			return fmt.Errorf("dependency cycle detected at %s", name)
		case 2:
			return nil
		}
		visited[name] = 1
		for dep := range plan[name].PendingDeps {
			if err := visit(dep); err != nil {
				return err
			}
		}
		visited[name] = 2
		return nil
	}
	for _, name := range order {
		if err := visit(name); err != nil {
			return nil, nil, err
		}
	}
	return plan, order, nil
}

func selectTools(tools []config.Tool, mode RunMode, category, selected string) []config.Tool {
	selected = strings.TrimSpace(selected)
	var out []config.Tool
	for _, tool := range tools {
		if !tool.Enabled {
			continue
		}
		switch mode {
		case RunAll:
			out = append(out, tool)
		case RunCategory:
			if tool.Category == category {
				out = append(out, tool)
			}
		case RunSelected:
			if tool.Name == selected {
				out = append(out, tool)
			}
		}
	}
	return out
}

func blockedByFailure(plan map[string]*toolState, state *toolState) (string, bool) {
	for _, dep := range state.Tool.DependsOn {
		depState, ok := plan[dep]
		if !ok {
			continue
		}
		if depState.Failed || depState.Skipped {
			return fmt.Sprintf("skipped because dependency %s did not complete successfully", dep), true
		}
	}
	return "", false
}

func waitingOnFiles(cfg *config.App, tool config.Tool) (string, bool) {
	vars := templateVars(cfg, tool)
	var missing []string
	for _, required := range tool.RequiresFiles {
		path := filepath.Clean(expandTemplate(required, vars))
		if fileExists(path) {
			continue
		}
		missing = append(missing, path)
	}
	if len(missing) == 0 {
		return "", false
	}
	return fmt.Sprintf("waiting on files: %s", strings.Join(missing, ", ")), true
}

func maybeEmitWaiting(ch chan<- Event, state *toolState, reason string) {
	state.WaitingReason = reason
	state.Status.State = "waiting"
	state.Status.Error = reason
	if state.WaitingEmitted == reason {
		return
	}
	state.WaitingEmitted = reason
	emit(ch, Event{Type: EventWaiting, Tool: state.Tool.Name, Text: reason, Node: cloneStatus(state.Status)})
}

func joinPendingDeps(pending map[string]struct{}) string {
	deps := make([]string, 0, len(pending))
	for dep := range pending {
		deps = append(deps, dep)
	}
	sort.Strings(deps)
	return strings.Join(deps, ", ")
}

func markDeadlocked(plan map[string]*toolState, cfg *config.App, ch chan<- Event) {
	for _, state := range plan {
		if state.Started || state.Finished || state.Skipped || state.Failed {
			continue
		}
		reason := state.WaitingReason
		if reason == "" {
			reason = "skipped because prerequisites were never satisfied"
		}
		if fileReason, waiting := waitingOnFiles(cfg, state.Tool); waiting {
			reason = fileReason
		}
		state.Skipped = true
		state.FailureReason = reason
		state.Status.State = "skipped"
		state.Status.Error = reason
		state.Status.FinishedAt = time.Now()
		emit(ch, Event{Type: EventSkipped, Tool: state.Tool.Name, Text: reason, Node: cloneStatus(state.Status)})
	}
}

func markRemainderSkipped(plan map[string]*toolState, ch chan<- Event, reason string) {
	for _, state := range plan {
		if state.Started || state.Finished || state.Skipped || state.Failed {
			continue
		}
		state.Skipped = true
		state.FailureReason = reason
		state.Status.State = "skipped"
		state.Status.Error = reason
		state.Status.FinishedAt = time.Now()
		emit(ch, Event{Type: EventSkipped, Tool: state.Tool.Name, Text: reason, Node: cloneStatus(state.Status)})
	}
}

func countStates(plan map[string]*toolState, fn func(*toolState) bool) int {
	count := 0
	for _, state := range plan {
		if fn(state) {
			count++
		}
	}
	return count
}

func terminalCount(plan map[string]*toolState) int {
	return countStates(plan, func(state *toolState) bool {
		return state.Finished || state.Failed || state.Skipped
	})
}

func runTool(ctx context.Context, cfg *config.App, tool config.Tool, ch chan<- Event) runResult {
	vars := templateVars(cfg, tool)
	outputPath := filepath.Clean(expandTemplate(filepath.Join(cfg.Workspace, tool.Output), vars))
	result := runResult{ToolName: tool.Name, Category: tool.Category, OutputPath: outputPath}

	if err := os.MkdirAll(filepath.Dir(outputPath), 0o755); err != nil {
		result.Err = err
		result.ExitCode = exitCodeFromErr(err)
		return result
	}

	outputFile, err := os.Create(outputPath)
	if err != nil {
		result.Err = err
		result.ExitCode = exitCodeFromErr(err)
		return result
	}
	defer outputFile.Close()

	switch tool.Mode {
	case "builtin-crtsh":
		result.Err = runCRTSh(ctx, cfg.Target.Domain, outputFile, ch)
	case "exec":
		result.Err = runExec(ctx, cfg, tool, vars, outputFile, ch)
	case "shell":
		result.Err = runShell(ctx, cfg, tool, vars, outputFile, ch)
	default:
		result.Err = fmt.Errorf("unsupported tool mode: %s", tool.Mode)
	}

	result.ExitCode = exitCodeFromErr(result.Err)
	result.ArtifactCount = countArtifacts(outputPath)
	return result
}

func runCRTSh(ctx context.Context, domain string, out io.Writer, ch chan<- Event) error {
	url := fmt.Sprintf("https://crt.sh/?q=%%25.%s&output=json", domain)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "bugbountytui/0.3")

	client := &http.Client{Timeout: 60 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("crt.sh returned status %d", resp.StatusCode)
	}

	var entries []crtShEntry
	if err := json.NewDecoder(resp.Body).Decode(&entries); err != nil {
		return err
	}

	seen := map[string]struct{}{}
	lines := make([]string, 0, len(entries))
	for _, entry := range entries {
		for _, raw := range strings.Split(entry.NameValue, "\n") {
			candidate := strings.TrimSpace(strings.ToLower(raw))
			candidate = strings.TrimPrefix(candidate, "*.")
			if candidate == "" {
				continue
			}
			if !strings.HasSuffix(candidate, "."+domain) && candidate != domain {
				continue
			}
			if _, ok := seen[candidate]; ok {
				continue
			}
			seen[candidate] = struct{}{}
			lines = append(lines, candidate)
		}
	}
	sort.Strings(lines)
	for _, line := range lines {
		fmt.Fprintln(out, line)
	}
	emit(ch, Event{Type: EventLog, Tool: "crt.sh", Text: fmt.Sprintf("crt.sh wrote %d subdomains", len(lines))})
	return nil
}

func runExec(ctx context.Context, cfg *config.App, tool config.Tool, vars map[string]string, out io.Writer, ch chan<- Event) error {
	bin := expandTemplate(tool.Bin, vars)
	args := make([]string, 0, len(tool.Args))
	for _, arg := range tool.Args {
		args = append(args, expandTemplate(arg, vars))
	}

	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.Dir = resolveWorkingDir(cfg.Workspace, expandTemplate(tool.WorkingDir, vars))
	cmd.Env = envForTool(cfg, tool.Env)

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	stderr, err := cmd.StderrPipe()
	if err != nil {
		return err
	}

	emit(ch, Event{Type: EventLog, Tool: tool.Name, Text: "$ " + shellQuote(bin, args)})
	if err := cmd.Start(); err != nil {
		return err
	}

	var wg sync.WaitGroup
	wg.Add(2)
	go stream(stdout, out, tool.Name, ch, &wg)
	go stream(stderr, io.Discard, tool.Name, ch, &wg)
	wg.Wait()
	return cmd.Wait()
}

func runShell(ctx context.Context, cfg *config.App, tool config.Tool, vars map[string]string, out io.Writer, ch chan<- Event) error {
	cmdStr := expandTemplate(tool.Shell, vars)
	cmd := exec.CommandContext(ctx, "bash", "-lc", cmdStr)
	cmd.Dir = resolveWorkingDir(cfg.Workspace, expandTemplate(tool.WorkingDir, vars))
	cmd.Env = envForTool(cfg, tool.Env)

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	stderr, err := cmd.StderrPipe()
	if err != nil {
		return err
	}

	emit(ch, Event{Type: EventLog, Tool: tool.Name, Text: "$ " + cmdStr})
	if err := cmd.Start(); err != nil {
		return err
	}

	var wg sync.WaitGroup
	wg.Add(2)
	go stream(stdout, out, tool.Name, ch, &wg)
	go stream(stderr, io.Discard, tool.Name, ch, &wg)
	wg.Wait()
	return cmd.Wait()
}

func stream(r io.Reader, out io.Writer, tool string, ch chan<- Event, wg *sync.WaitGroup) {
	defer wg.Done()
	scanner := bufio.NewScanner(r)
	buf := make([]byte, 0, 1024*1024)
	scanner.Buffer(buf, 1024*1024)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.TrimSpace(line) == "" {
			continue
		}
		fmt.Fprintln(out, line)
		emit(ch, Event{Type: EventLog, Tool: tool, Text: line})
	}
}

func templateVars(cfg *config.App, tool config.Tool) map[string]string {
	workspace := cfg.Workspace
	return map[string]string{
		"target":          cfg.Target.Domain,
		"domain":          cfg.Target.Domain,
		"workspace":       workspace,
		"output":          filepath.Join(workspace, tool.Output),
		"history_dir":     filepath.Join(workspace, "history"),
		"subdomains_file": filepath.Join(workspace, "subdomains", "all_subdomains.txt"),
		"dns_file":        filepath.Join(workspace, "dns", "all_dns.txt"),
		"alive_file":      filepath.Join(workspace, "probe", "httpx.txt"),
		"probe_file":      filepath.Join(workspace, "probe", "all_probe.txt"),
		"ports_file":      filepath.Join(workspace, "probe", "naabu.txt"),
		"urls_file":       filepath.Join(workspace, "urls", "all_urls.txt"),
		"params_file":     filepath.Join(workspace, "params", "all_params.txt"),
		"content_file":    filepath.Join(workspace, "content", "all_content.txt"),
		"js_file":         filepath.Join(workspace, "js", "all_js.txt"),
		"secrets_file":    filepath.Join(workspace, "secrets", "all_secrets.txt"),
		"vulns_file":      filepath.Join(workspace, "vulns", "all_vulns.txt"),
		"screens_file":    filepath.Join(workspace, "screenshots", "all_screenshots.txt"),
		"intel_file":      filepath.Join(workspace, "intel", "all_intel.txt"),
		"api_file":        filepath.Join(workspace, "api", "all_api.txt"),
		"base_url":        "https://" + cfg.Target.Domain,
	}
}

func expandTemplate(input string, vars map[string]string) string {
	out := input
	for key, value := range vars {
		out = strings.ReplaceAll(out, "{{"+key+"}}", value)
	}
	return out
}

func envForTool(cfg *config.App, extra map[string]string) []string {
	env := os.Environ()
	if cfg != nil {
		env = append(env,
			"PROJECTDISCOVERY_API_KEY="+os.ExpandEnv(cfg.APIKeys.ProjectDiscovery),
			"TRICKEST_API_KEY="+os.ExpandEnv(cfg.APIKeys.Trickest),
			"VIRUSTOTAL_API_KEY="+os.ExpandEnv(cfg.APIKeys.VirusTotal),
			"FOFA_API_KEY="+os.ExpandEnv(cfg.APIKeys.FOFA),
			"SHODAN_API_KEY="+os.ExpandEnv(cfg.APIKeys.Shodan),
			"CENSYS_API_KEY="+os.ExpandEnv(cfg.APIKeys.Censys),
		)
	}
	for k, v := range extra {
		env = append(env, k+"="+os.ExpandEnv(v))
	}
	return env
}

func resolveWorkingDir(workspace, wd string) string {
	if strings.TrimSpace(wd) == "" {
		return workspace
	}
	if filepath.IsAbs(wd) {
		return wd
	}
	return filepath.Join(workspace, wd)
}

func shellQuote(bin string, args []string) string {
	parts := append([]string{bin}, args...)
	for i, part := range parts {
		if strings.ContainsAny(part, " \t\n\"'") {
			parts[i] = fmt.Sprintf("%q", part)
		}
	}
	return strings.Join(parts, " ")
}

func mergeCategoryAggregate(workspace, category string) {
	aggregates := map[string]string{
		"subdomains":  "all_subdomains.txt",
		"dns":         "all_dns.txt",
		"probe":       "all_probe.txt",
		"urls":        "all_urls.txt",
		"params":      "all_params.txt",
		"content":     "all_content.txt",
		"js":          "all_js.txt",
		"secrets":     "all_secrets.txt",
		"vulns":       "all_vulns.txt",
		"takeover":    "all_takeovers.txt",
		"screenshots": "all_screenshots.txt",
		"intel":       "all_intel.txt",
		"api":         "all_api.txt",
	}
	aggregateName, ok := aggregates[category]
	if !ok {
		return
	}
	mergeCategoryOutputs(workspace, category, aggregateName)
}

func mergeAllCategories(workspace string) {
	for _, category := range []string{"subdomains", "dns", "probe", "urls", "params", "content", "js", "secrets", "vulns", "takeover", "screenshots", "intel", "api"} {
		mergeCategoryAggregate(workspace, category)
	}
}

func mergeCategoryOutputs(workspace, category, aggregateName string) {
	dir := filepath.Join(workspace, category)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	seen := map[string]struct{}{}
	var lines []string
	for _, entry := range entries {
		if entry.IsDir() || filepath.Base(entry.Name()) == aggregateName {
			continue
		}
		path := filepath.Join(dir, entry.Name())
		b, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		scanner := bufio.NewScanner(bytes.NewReader(b))
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line == "" {
				continue
			}
			if _, ok := seen[line]; ok {
				continue
			}
			seen[line] = struct{}{}
			lines = append(lines, line)
		}
	}
	sort.Strings(lines)
	var buf bytes.Buffer
	for _, line := range lines {
		buf.WriteString(line)
		buf.WriteByte('\n')
	}
	_ = os.MkdirAll(dir, 0o755)
	_ = os.WriteFile(filepath.Join(dir, aggregateName), buf.Bytes(), 0o644)
}

func countArtifacts(path string) int {
	b, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	scanner := bufio.NewScanner(bytes.NewReader(b))
	count := 0
	for scanner.Scan() {
		if strings.TrimSpace(scanner.Text()) != "" {
			count++
		}
	}
	return count
}

func fileExists(path string) bool {
	info, err := os.Stat(path)
	if err != nil {
		return false
	}
	return !info.IsDir()
}

func exitCodeFromErr(err error) int {
	if err == nil {
		return 0
	}
	var exitErr *exec.ExitError
	if errors.As(err, &exitErr) {
		return exitErr.ExitCode()
	}
	return 1
}

func cloneStatus(status ToolStatus) *ToolStatus {
	copyStatus := status
	copyStatus.DependsOn = append([]string(nil), status.DependsOn...)
	copyStatus.RequiresFiles = append([]string(nil), status.RequiresFiles...)
	return &copyStatus
}

func emit(ch chan<- Event, event Event) {
	select {
	case ch <- event:
	default:
		// Avoid deadlocking the runner if the UI stops listening.
	}
}
