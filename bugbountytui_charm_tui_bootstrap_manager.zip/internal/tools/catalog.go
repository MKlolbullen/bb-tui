package tools

import "bugbountytui/internal/config"

func execTool(name, category, description, bin, output string, enabled bool, args ...string) config.Tool {
	return config.Tool{
		Name:        name,
		Category:    category,
		Description: description,
		Enabled:     enabled,
		Mode:        "exec",
		Bin:         bin,
		Args:        args,
		Output:      output,
	}
}

func shellTool(name, category, description, shell, output string, enabled bool) config.Tool {
	return config.Tool{
		Name:        name,
		Category:    category,
		Description: description,
		Enabled:     enabled,
		Mode:        "shell",
		Shell:       shell,
		Output:      output,
	}
}

func DefaultConfig() *config.App {
	tools := []config.Tool{
		{
			Name:        "crt.sh",
			Category:    "subdomains",
			Description: "Built-in passive certificate transparency enumeration",
			Enabled:     true,
			Mode:        "builtin-crtsh",
			Output:      "subdomains/crtsh.txt",
		},
		execTool("assetfinder", "subdomains", "Passive subdomain discovery", "assetfinder", "subdomains/assetfinder.txt", true, "--subs-only", "{{target}}"),
		execTool("subfinder", "subdomains", "ProjectDiscovery passive subdomain enumeration", "subfinder", "subdomains/subfinder.txt", true, "-silent", "-d", "{{target}}"),
		execTool("chaos-client", "subdomains", "ProjectDiscovery Chaos dataset query", "chaos", "subdomains/chaos.txt", true, "-silent", "-d", "{{target}}"),
		execTool("amass enum", "subdomains", "OWASP Amass passive enumeration", "amass", "subdomains/amass.txt", true, "enum", "-passive", "-d", "{{target}}"),
		execTool("findomain", "subdomains", "Fast subdomain discovery", "findomain", "subdomains/findomain.txt", false, "-t", "{{target}}", "-q"),
		execTool("github-subdomains", "subdomains", "GitHub-based subdomain discovery", "github-subdomains", "subdomains/github-subdomains.txt", false, "-d", "{{target}}"),
		shellTool("shuffledns", "subdomains", "Mass DNS validation and bruteforce. Edit resolver/wordlist paths locally.", `shuffledns -d {{target}} -list {{subdomains_file}} -r /path/to/resolvers.txt -silent`, "subdomains/shuffledns.txt", false),

		execTool("dnsx", "dns", "Resolve and validate discovered subdomains", "dnsx", "dns/dnsx.txt", true, "-l", "{{subdomains_file}}", "-silent"),
		execTool("cdncheck", "dns", "Identify CDN/WAF presence", "cdncheck", "dns/cdncheck.txt", false, "-l", "{{subdomains_file}}", "-silent"),

		execTool("httpx", "probe", "Probe subdomains and collect alive URLs", "httpx", "probe/httpx.txt", true, "-silent", "-l", "{{subdomains_file}}", "-tech-detect", "-title", "-follow-redirects"),
		shellTool("httprobe", "probe", "Simple HTTP probe from enumerated hosts", `cat {{subdomains_file}} | httprobe`, "probe/httprobe.txt", false),
		execTool("naabu", "probe", "Fast port scanning on discovered hosts", "naabu", "probe/naabu.txt", false, "-list", "{{subdomains_file}}", "-silent", "-top-ports", "100"),
		execTool("tlsx", "probe", "TLS metadata collection", "tlsx", "probe/tlsx.txt", false, "-l", "{{subdomains_file}}", "-silent"),

		execTool("urlfinder", "urls", "Historical and passive URL gathering", "urlfinder", "urls/urlfinder.txt", true, "-d", "{{target}}"),
		execTool("gau", "urls", "Fetch archived URLs from several providers", "gau", "urls/gau.txt", true, "--subs", "{{target}}"),
		shellTool("waybackurls", "urls", "Fetch URLs from the Wayback Machine", `echo {{target}} | waybackurls`, "urls/waybackurls.txt", false),
		execTool("katana", "urls", "Fast crawler for alive URLs", "katana", "urls/katana.txt", true, "-list", "{{alive_file}}", "-silent", "-jc", "-kf"),
		shellTool("hakrawler", "urls", "Crawler for content and URL extraction", `cat {{alive_file}} | hakrawler -plain`, "urls/hakrawler.txt", false),

		execTool("paramspider", "params", "Mine parameterized endpoints from archives", "paramspider", "params/paramspider.txt", false, "-d", "{{target}}"),
		execTool("arjun", "params", "Parameter discovery on a selected endpoint", "arjun", "params/arjun.txt", false, "-u", "{{base_url}}"),
		shellTool("gf xss", "params", "Pattern extraction for XSS candidates", `cat {{urls_file}} | gf xss`, "params/gf-xss.txt", false),
		shellTool("gf sqli", "params", "Pattern extraction for SQLi candidates", `cat {{urls_file}} | gf sqli`, "params/gf-sqli.txt", false),
		shellTool("gf ssrf", "params", "Pattern extraction for SSRF candidates", `cat {{urls_file}} | gf ssrf`, "params/gf-ssrf.txt", false),
		shellTool("qsreplace", "params", "Replace parameter values with a marker payload", `cat {{params_file}} | qsreplace FUZZ`, "params/qsreplace.txt", false),

		execTool("ffuf", "content", "Content discovery against a selected base URL", "ffuf", "content/ffuf.txt", false, "-u", "{{base_url}}/FUZZ", "-w", "/usr/share/seclists/Discovery/Web-Content/common.txt", "-mc", "all"),
		execTool("feroxbuster", "content", "Recursive content discovery", "feroxbuster", "content/feroxbuster.txt", false, "-u", "{{base_url}}", "-w", "/usr/share/seclists/Discovery/Web-Content/common.txt", "-q"),
		shellTool("dirsearch", "content", "Directory brute force. Edit flags locally if desired.", `dirsearch -u {{base_url}} -w /usr/share/seclists/Discovery/Web-Content/common.txt --plain-text-report={{output}} && cat {{output}}`, "content/dirsearch.txt", false),

		shellTool("subjs", "js", "Collect JavaScript URLs from alive hosts", `cat {{alive_file}} | subjs`, "js/subjs.txt", false),
		shellTool("jsubfinder", "js", "Extract endpoints and secrets from JavaScript assets", `jsubfinder -l {{urls_file}}`, "js/jsubfinder.txt", false),
		shellTool("cariddi", "js", "Asset discovery and secret/endpoint hunting", `cat {{alive_file}} | cariddi -intensive`, "js/cariddi.txt", false),
		shellTool("linkfinder", "js", "Run LinkFinder over a chosen target list. Edit path to your local script.", `while read -r u; do python3 /path/to/LinkFinder/linkfinder.py -i "$u" -o cli; done < {{alive_file}}`, "js/linkfinder.txt", false),

		execTool("xsrfprobe", "secrets", "XSRF probing against a chosen target", "xsrfprobe", "secrets/xsrfprobe.txt", false, "-u", "{{base_url}}"),
		execTool("xsstrike", "secrets", "XSS testing and crawling against a chosen target", "xsstrike", "secrets/xsstrike.txt", false, "-u", "{{base_url}}", "--crawl"),

		execTool("nuclei", "vulns", "ProjectDiscovery template-based scanner", "nuclei", "vulns/nuclei.txt", false, "-l", "{{alive_file}}", "-silent", "-rl", "50"),
		shellTool("jaeles", "vulns", "Jaeles signature-based web scanner. Edit signature path locally.", `jaeles scan -U {{alive_file}} -s ~/.jaeles/base-signatures`, "vulns/jaeles.txt", false),
		execTool("dalfox", "vulns", "XSS scanner for parameterized URLs", "dalfox", "vulns/dalfox.txt", false, "file", "{{params_file}}", "--silence"),
		shellTool("kxss", "vulns", "Reflected parameter heuristic for XSS discovery", `cat {{params_file}} | kxss`, "vulns/kxss.txt", false),
		execTool("corsy", "vulns", "CORS misconfiguration checker", "corsy", "vulns/corsy.txt", false, "-i", "{{alive_file}}"),
		shellTool("sqlmap", "vulns", "SQL injection testing. Aggressive by nature; leave disabled until you mean it.", `sqlmap -m {{params_file}} --batch --random-agent`, "vulns/sqlmap.txt", false),

		execTool("subzy", "takeover", "Subdomain takeover detection", "subzy", "takeover/subzy.txt", false, "run", "--targets", "{{subdomains_file}}", "--hide_fails"),

		shellTool("gowitness", "screenshots", "Screenshot alive targets. Adjust for your installed gowitness version if needed.", `gowitness scan file -f {{alive_file}}`, "screenshots/gowitness.txt", false),

		execTool("uncover", "intel", "Query Shodan/Censys/FOFA/VirusTotal via ProjectDiscovery Uncover", "uncover", "intel/uncover.txt", false, "-q", "{{target}}", "-silent"),
		execTool("asnmap", "intel", "Map target domain into ASN information", "asnmap", "intel/asnmap.txt", false, "-domain", "{{target}}"),

		shellTool("kiterunner", "api", "API route discovery. Edit the local .kite wordlist path.", `kr scan {{base_url}} -w /path/to/routes.kite`, "api/kiterunner.txt", false),
	}

	for i := range tools {
		switch tools[i].Name {
		case "subfinder":
			tools[i].Env = map[string]string{"SUBFINDER_PROVIDER_CONFIG": "${SUBFINDER_PROVIDER_CONFIG}"}
		case "github-subdomains":
			tools[i].Env = map[string]string{"GITHUB_TOKEN": "${GITHUB_TOKEN}"}
		}
	}

	for i := range tools {
		switch tools[i].Name {
		case "dnsx", "cdncheck", "httpx", "httprobe", "naabu", "tlsx", "subzy":
			tools[i].RequiresFiles = []string{"{{subdomains_file}}"}
		case "katana", "hakrawler", "subjs", "cariddi", "gowitness", "nuclei", "jaeles", "corsy":
			tools[i].DependsOn = []string{"httpx"}
			tools[i].RequiresFiles = []string{"{{alive_file}}"}
		case "paramspider":
			tools[i].RequiresFiles = []string{"{{urls_file}}"}
		case "arjun", "ffuf", "feroxbuster", "dirsearch", "kiterunner", "xsrfprobe", "xsstrike":
			tools[i].DependsOn = []string{"httpx"}
			tools[i].RequiresFiles = []string{"{{alive_file}}"}
		case "gf xss", "gf sqli", "gf ssrf":
			tools[i].DependsOn = []string{"urlfinder", "gau", "katana", "hakrawler"}
			tools[i].RequiresFiles = []string{"{{urls_file}}"}
		case "qsreplace", "dalfox", "kxss", "sqlmap":
			tools[i].RequiresFiles = []string{"{{params_file}}"}
		case "jsubfinder":
			tools[i].RequiresFiles = []string{"{{urls_file}}"}
		case "linkfinder":
			tools[i].DependsOn = []string{"httpx"}
			tools[i].RequiresFiles = []string{"{{alive_file}}"}
		}
	}

	return &config.App{
		Workspace: "./workspace",
		Target:    config.Target{Domain: "example.com"},
		Runner: config.Runner{
			MaxParallel: 4,
			FailFast:    false,
		},
		APIKeys: config.APIKeys{
			ProjectDiscovery: "${PROJECTDISCOVERY_API_KEY}",
			Trickest:         "${TRICKEST_API_KEY}",
			VirusTotal:       "${VIRUSTOTAL_API_KEY}",
			FOFA:             "${FOFA_API_KEY}",
			Shodan:           "${SHODAN_API_KEY}",
			Censys:           "${CENSYS_API_KEY}",
		},
		Tools: tools,
	}
}
