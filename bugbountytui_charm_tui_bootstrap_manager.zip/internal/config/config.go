package config

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
)

type APIKeys struct {
	ProjectDiscovery string `yaml:"projectdiscovery"`
	Trickest         string `yaml:"trickest"`
	VirusTotal       string `yaml:"virustotal"`
	FOFA             string `yaml:"fofa"`
	Shodan           string `yaml:"shodan"`
	Censys           string `yaml:"censys"`
}

type Target struct {
	Domain string `yaml:"domain"`
}

type Runner struct {
	MaxParallel int  `yaml:"max_parallel"`
	FailFast    bool `yaml:"fail_fast"`
}

type Tool struct {
	Name          string            `yaml:"name"`
	Category      string            `yaml:"category"`
	Description   string            `yaml:"description"`
	Enabled       bool              `yaml:"enabled"`
	Mode          string            `yaml:"mode"`
	Bin           string            `yaml:"bin,omitempty"`
	Args          []string          `yaml:"args,omitempty"`
	Shell         string            `yaml:"shell,omitempty"`
	Output        string            `yaml:"output"`
	Env           map[string]string `yaml:"env,omitempty"`
	WorkingDir    string            `yaml:"working_dir,omitempty"`
	DependsOn     []string          `yaml:"depends_on,omitempty"`
	RequiresFiles []string          `yaml:"requires_files,omitempty"`
}

type App struct {
	Workspace string  `yaml:"workspace"`
	Target    Target  `yaml:"target"`
	Runner    Runner  `yaml:"runner"`
	APIKeys   APIKeys `yaml:"api_keys"`
	Tools     []Tool  `yaml:"tools"`
}

func (a *App) Validate() error {
	if strings.TrimSpace(a.Workspace) == "" {
		return errors.New("workspace cannot be empty")
	}
	if a.Runner.MaxParallel <= 0 {
		a.Runner.MaxParallel = 3
	}
	if len(a.Tools) == 0 {
		return errors.New("no tools configured")
	}
	seen := make(map[string]struct{}, len(a.Tools))
	for _, tool := range a.Tools {
		name := strings.TrimSpace(tool.Name)
		if name == "" {
			return errors.New("tool name cannot be empty")
		}
		if _, ok := seen[name]; ok {
			return fmt.Errorf("duplicate tool name: %s", name)
		}
		seen[name] = struct{}{}
		if strings.TrimSpace(tool.Category) == "" {
			return fmt.Errorf("tool %s missing category", name)
		}
		if strings.TrimSpace(tool.Output) == "" {
			return fmt.Errorf("tool %s missing output path", name)
		}
	}
	return nil
}

func Load(path string) (*App, error) {
	path = filepath.Clean(path)
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}

	var cfg App
	if err := yaml.Unmarshal(b, &cfg); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func Save(path string, cfg *App) error {
	if err := cfg.Validate(); err != nil {
		return err
	}
	path = filepath.Clean(path)
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return fmt.Errorf("create config dir: %w", err)
	}
	b, err := yaml.Marshal(cfg)
	if err != nil {
		return fmt.Errorf("marshal config: %w", err)
	}
	if err := os.WriteFile(path, b, 0o600); err != nil {
		return fmt.Errorf("write config: %w", err)
	}
	return nil
}
