package app

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"bugbountytui/internal/bootstrap"
	"bugbountytui/internal/config"
	"bugbountytui/internal/history"
	"bugbountytui/internal/runner"
	"bugbountytui/internal/tools"

	"charm.land/bubbles/v2/textinput"
	tea "charm.land/bubbletea/v2"
	"charm.land/lipgloss/v2"
)

type focusPanel int

type centerView int

const (
	focusTarget focusPanel = iota
	focusTools
	focusCenter
	focusFields
	focusEditor
)

const (
	viewGraph centerView = iota
	viewArtifacts
	viewHistory
	viewBootstrap
	viewHelp
)

type runnerEventMsg struct{ Event runner.Event }
type runCompletedMsg struct{}
type tickMsg time.Time
type bootstrapScannedMsg struct {
	Report bootstrap.Report
	Err    error
}

type fieldDef struct {
	Name     string
	Editable bool
}

type runSession struct {
	Mode      runner.RunMode
	Category  string
	Selected  string
	StartedAt time.Time
}

type artifactEntry struct {
	Path    string
	RelPath string
	Size    int64
	ModTime time.Time
}

type model struct {
	cfg               *config.App
	configPath        string
	categories        []string
	categoryIdx       int
	toolIdx           int
	fieldIdx          int
	focus             focusPanel
	editing           bool
	centerView        centerView
	width             int
	height            int
	logs              []string
	status            string
	isRunning         bool
	runCancel         context.CancelFunc
	events            <-chan runner.Event
	now               time.Time
	targetInput       textinput.Model
	editorInput       textinput.Model
	runNodes          map[string]runner.ToolStatus
	runOrder          []string
	runMeta           runSession
	historyIdx        int
	historyRuns       []history.RunSummary
	artifactIdx       int
	artifacts         []artifactEntry
	bootstrapReport   bootstrap.Report
	bootstrapScanning bool
}

func Run(configPath string) error {
	cfg, err := config.Load(configPath)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			cfg = tools.DefaultConfig()
			if saveErr := config.Save(configPath, cfg); saveErr != nil {
				return fmt.Errorf("config missing and default config creation failed: %w", saveErr)
			}
		} else {
			return err
		}
	}

	m := initialModel(cfg, configPath)
	p := tea.NewProgram(m, tea.WithAltScreen())
	_, err = p.Run()
	return err
}

func initialModel(cfg *config.App, configPath string) model {
	target := textinput.New()
	target.Placeholder = "example.com"
	target.SetWidth(40)
	target.SetValue(cfg.Target.Domain)
	_ = target.Focus()

	editor := textinput.New()
	editor.Placeholder = "edit value"
	editor.SetWidth(60)

	m := model{
		cfg:               cfg,
		configPath:        configPath,
		categories:        collectCategories(cfg.Tools),
		focus:             focusTarget,
		centerView:        viewGraph,
		status:            "ready",
		now:               time.Now(),
		logs:              []string{"Press r to run category, R to run all, x to run selected tool, a for artifacts, H for history, ? for help, ctrl+s to save config."},
		targetInput:       target,
		editorInput:       editor,
		runNodes:          make(map[string]runner.ToolStatus),
		bootstrapScanning: true,
	}
	m.refreshArtifacts()
	m.refreshHistory()
	if len(m.categories) == 0 {
		m.categories = []string{"uncategorized"}
	}
	return m
}

func (m model) Init() tea.Cmd {
	return scanBootstrapCmd(m.cfg)
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd

	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width = msg.Width
		m.height = msg.Height
		m.targetInput.SetWidth(max(20, m.width/4))
		m.editorInput.SetWidth(max(24, m.width/3))
		return m, nil

	case tickMsg:
		m.now = time.Time(msg)
		if m.isRunning {
			return m, tickCmd()
		}
		return m, nil

	case bootstrapScannedMsg:
		m.bootstrapScanning = false
		if msg.Err != nil {
			m.status = "bootstrap scan failed: " + msg.Err.Error()
			m.logs = append(m.logs, "[bootstrap] scan failed: "+msg.Err.Error())
			m.trimLogs()
			return m, nil
		}
		m.bootstrapReport = msg.Report
		m.status = fmt.Sprintf("bootstrap scanned: %d runnable, %d missing, %d partial", msg.Report.Summary.Runnable, msg.Report.Summary.Missing, msg.Report.Summary.Partial)
		m.logs = append(m.logs, fmt.Sprintf("[bootstrap] scan complete: %d runnable, %d missing, %d partial", msg.Report.Summary.Runnable, msg.Report.Summary.Missing, msg.Report.Summary.Partial))
		m.trimLogs()
		return m, nil

	case tea.KeyPressMsg:
		if m.isRunning {
			switch msg.String() {
			case "ctrl+c", "q":
				if m.runCancel != nil {
					m.runCancel()
				}
				return m, tea.Quit
			case "esc":
				if m.runCancel != nil {
					m.runCancel()
					m.status = "cancel requested"
				}
				return m, nil
			}
		}

		if m.editing {
			switch msg.String() {
			case "esc":
				m.editing = false
				m.focus = focusFields
				m.editorInput.Blur()
				m.status = "edit cancelled"
				return m, nil
			case "enter":
				fieldName := m.selectedField().Name
				m.commitEditor()
				m.editing = false
				m.focus = focusFields
				m.editorInput.Blur()
				m.status = "field updated"
				if fieldName == "Mode" || fieldName == "Bin" || fieldName == "Shell" {
					m.bootstrapScanning = true
					return m, scanBootstrapCmd(m.cfg)
				}
				return m, nil
			}
			var cmd tea.Cmd
			m.editorInput, cmd = m.editorInput.Update(msg)
			return m, cmd
		}

		switch msg.String() {
		case "ctrl+c", "q":
			return m, tea.Quit
		case "tab":
			m.focus = (m.focus + 1) % 4
			m.syncFocus()
			return m, nil
		case "shift+tab":
			m.focus = (m.focus + 3) % 4
			m.syncFocus()
			return m, nil
		case "left", "h":
			if m.focus == focusTools && m.categoryIdx > 0 {
				m.categoryIdx--
				m.toolIdx = 0
				m.fieldIdx = 0
			}
			return m, nil
		case "right", "l":
			if m.focus == focusTools && m.categoryIdx < len(m.categories)-1 {
				m.categoryIdx++
				m.toolIdx = 0
				m.fieldIdx = 0
			}
			return m, nil
		case "up", "k":
			return m.navigateUp()
		case "down", "j":
			return m.navigateDown()
		case "g":
			m.centerView = viewGraph
			m.status = "graph/status view enabled"
			return m, nil
		case "a":
			m.centerView = viewArtifacts
			m.refreshArtifacts()
			m.status = "artifact browser enabled"
			return m, nil
		case "H":
			m.centerView = viewHistory
			m.refreshHistory()
			m.status = "run history view enabled"
			return m, nil
		case "b":
			m.centerView = viewBootstrap
			m.status = "bootstrap manager view enabled"
			return m, nil
		case "B":
			m.centerView = viewBootstrap
			m.bootstrapScanning = true
			m.status = "refreshing bootstrap checks"
			return m, scanBootstrapCmd(m.cfg)
		case "?":
			m.centerView = viewHelp
			m.status = "help view enabled"
			return m, nil
		case "]":
			m.centerView = (m.centerView + 1) % 5
			m.status = "center view changed"
			if m.centerView == viewArtifacts {
				m.refreshArtifacts()
			}
			if m.centerView == viewHistory {
				m.refreshHistory()
			}
			return m, nil
		case "[":
			m.centerView = (m.centerView + 4) % 5
			m.status = "center view changed"
			if m.centerView == viewArtifacts {
				m.refreshArtifacts()
			}
			if m.centerView == viewHistory {
				m.refreshHistory()
			}
			return m, nil
		case " ":
			if m.focus == focusFields && m.selectedField().Name == "Enabled" {
				tool := m.selectedTool()
				tool.Enabled = !tool.Enabled
				m.status = fmt.Sprintf("%s enabled=%v", tool.Name, tool.Enabled)
			}
			return m, nil
		case "enter":
			if m.focus == focusFields {
				field := m.selectedField()
				if field.Editable {
					m.startEditing(field.Name)
				}
			}
			return m, nil
		case "ctrl+s":
			m.cfg.Target.Domain = strings.TrimSpace(m.targetInput.Value())
			if err := config.Save(m.configPath, m.cfg); err != nil {
				m.status = "save failed: " + err.Error()
				return m, nil
			}
			m.categories = collectCategories(m.cfg.Tools)
			m.refreshArtifacts()
			m.refreshHistory()
			m.bootstrapScanning = true
			m.status = "config saved to " + m.configPath
			return m, scanBootstrapCmd(m.cfg)
		case "r":
			return m, m.startRun(runner.RunCategory)
		case "R":
			return m, m.startRun(runner.RunAll)
		case "x":
			return m, m.startRun(runner.RunSelected)
		}

		if m.focus == focusTarget {
			var cmd tea.Cmd
			m.targetInput, cmd = m.targetInput.Update(msg)
			m.cfg.Target.Domain = strings.TrimSpace(m.targetInput.Value())
			return m, cmd
		}

	case runnerEventMsg:
		m.now = time.Now()
		m.applyRunnerEvent(msg.Event)
		if msg.Event.Type == runner.EventDone {
			m.isRunning = false
			m.status = msg.Event.Text
			m.runCancel = nil
			m.persistCurrentRun()
			m.refreshHistory()
			m.refreshArtifacts()
			return m, nil
		}
		return m, waitForRunnerEvent(m.events)

	case runCompletedMsg:
		m.isRunning = false
		m.runCancel = nil
		if m.status == "running" {
			m.status = "run ended"
		}
		m.persistCurrentRun()
		m.refreshHistory()
		m.refreshArtifacts()
		return m, nil
	}

	if m.focus == focusTarget {
		var cmd tea.Cmd
		m.targetInput, cmd = m.targetInput.Update(msg)
		cmds = append(cmds, cmd)
	}
	return m, tea.Batch(cmds...)
}

func (m *model) applyRunnerEvent(evt runner.Event) {
	if evt.Node != nil {
		if _, ok := m.runNodes[evt.Node.Tool]; !ok {
			m.runOrder = append(m.runOrder, evt.Node.Tool)
		}
		m.runNodes[evt.Node.Tool] = *evt.Node
	}
	if evt.Text != "" {
		prefix := evt.Tool
		if prefix == "" {
			prefix = "runner"
		}
		line := fmt.Sprintf("[%s] %s", prefix, evt.Text)
		if evt.Err != nil {
			line += ": " + evt.Err.Error()
		}
		m.logs = append(m.logs, line)
		m.trimLogs()
	}
	if evt.Type == runner.EventError && evt.Tool == "" && evt.Err != nil {
		m.status = evt.Err.Error()
	}
}

func (m model) View() string {
	styles := newStyles()

	header := styles.Header.Render("Bug Bounty TUI") + "  " + styles.Muted.Render("workflow-aware operator console")
	targetLine := styles.Label.Render("Target") + "\n" + m.targetInput.View()
	meta := []string{
		fmt.Sprintf("Config: %s", m.configPath),
		fmt.Sprintf("Workspace: %s", m.cfg.Workspace),
		fmt.Sprintf("Max parallel: %d", m.cfg.Runner.MaxParallel),
		fmt.Sprintf("Fail fast: %v", m.cfg.Runner.FailFast),
		fmt.Sprintf("Center view: %s", m.centerViewName()),
		fmt.Sprintf("Runs stored: %d", len(m.historyRuns)),
		fmt.Sprintf("Artifacts indexed: %d", len(m.artifacts)),
		fmt.Sprintf("Bootstrap: %s", m.bootstrapSummaryLine()),
	}

	catParts := make([]string, 0, len(m.categories))
	for i, cat := range m.categories {
		if i == m.categoryIdx {
			catParts = append(catParts, styles.ActiveCategory.Render(strings.ToUpper(cat)))
		} else {
			catParts = append(catParts, styles.Category.Render(strings.ToUpper(cat)))
		}
	}
	categoryBar := lipgloss.JoinHorizontal(lipgloss.Top, catParts...)

	toolPanelWidth := max(28, m.width/4)
	fieldPanelWidth := max(42, m.width/3)
	centerWidth := max(46, m.width-toolPanelWidth-fieldPanelWidth-6)
	logHeight := max(8, m.height/3)

	left := styles.Panel.Copy().Width(toolPanelWidth).Render(categoryBar + "\n\n" + m.renderTools())
	centerBody := targetLine + "\n\n" + styles.Muted.Render(strings.Join(meta, "\n")) + "\n\n"
	centerBody += m.renderCenter(centerWidth-4, max(10, m.height-logHeight-10))
	center := styles.Panel.Copy().Width(centerWidth).Render(centerBody)

	right := styles.Panel.Copy().Width(fieldPanelWidth).Render(m.renderFields())
	mainRow := lipgloss.JoinHorizontal(lipgloss.Top, left, center, right)

	logs := styles.LogPanel.Copy().Width(max(60, m.width-4)).Height(logHeight).Render(m.renderLogs(logHeight - 2))
	status := styles.Status.Render(" " + m.status + " ")

	return lipgloss.JoinVertical(lipgloss.Left,
		header,
		mainRow,
		logs,
		status,
	)
}

func (m model) renderCenter(width, height int) string {
	switch m.centerView {
	case viewArtifacts:
		return m.renderArtifacts(width, height)
	case viewHistory:
		return m.renderHistory(width, height)
	case viewBootstrap:
		return m.renderBootstrap(width, height)
	case viewHelp:
		return m.renderHelp()
	default:
		return m.renderRunGraph(width, height)
	}
}

func (m model) centerViewName() string {
	switch m.centerView {
	case viewArtifacts:
		return "artifacts"
	case viewHistory:
		return "history"
	case viewBootstrap:
		return "bootstrap"
	case viewHelp:
		return "help"
	default:
		return "graph/status"
	}
}

func (m *model) syncFocus() {
	if m.focus == focusTarget {
		_ = m.targetInput.Focus()
	} else {
		m.targetInput.Blur()
	}
}

func (m model) navigateUp() (tea.Model, tea.Cmd) {
	switch m.focus {
	case focusTools:
		if m.toolIdx > 0 {
			m.toolIdx--
			m.fieldIdx = 0
		}
	case focusCenter:
		switch m.centerView {
		case viewArtifacts:
			if m.artifactIdx > 0 {
				m.artifactIdx--
			}
		case viewHistory:
			if m.historyIdx > 0 {
				m.historyIdx--
			}
		}
	case focusFields:
		if m.fieldIdx > 0 {
			m.fieldIdx--
		}
	}
	return m, nil
}

func (m model) navigateDown() (tea.Model, tea.Cmd) {
	switch m.focus {
	case focusTools:
		if m.toolIdx < len(m.filteredToolIndices())-1 {
			m.toolIdx++
			m.fieldIdx = 0
		}
	case focusCenter:
		switch m.centerView {
		case viewArtifacts:
			if m.artifactIdx < len(m.artifacts)-1 {
				m.artifactIdx++
			}
		case viewHistory:
			if m.historyIdx < len(m.historyRuns)-1 {
				m.historyIdx++
			}
		}
	case focusFields:
		if m.fieldIdx < len(m.fields())-1 {
			m.fieldIdx++
		}
	}
	return m, nil
}

func (m *model) startEditing(fieldName string) {
	m.editing = true
	m.focus = focusEditor
	m.editorInput.SetValue(m.fieldValue(fieldName))
	_ = m.editorInput.Focus()
	m.status = "editing " + fieldName
}

func (m *model) commitEditor() {
	value := strings.TrimSpace(m.editorInput.Value())
	tool := m.selectedTool()
	switch m.selectedField().Name {
	case "Description":
		tool.Description = value
	case "Mode":
		tool.Mode = value
	case "Bin":
		tool.Bin = value
	case "Args":
		tool.Args = splitArgs(value)
	case "Shell":
		tool.Shell = value
	case "Output":
		tool.Output = value
	case "DependsOn":
		tool.DependsOn = splitCSV(value)
	case "RequiresFiles":
		tool.RequiresFiles = splitCSV(value)
	}
}

func (m *model) startRun(mode runner.RunMode) tea.Cmd {
	if m.isRunning {
		return nil
	}
	m.cfg.Target.Domain = strings.TrimSpace(m.targetInput.Value())
	m.runNodes = make(map[string]runner.ToolStatus)
	m.runOrder = nil
	ctx, cancel := context.WithCancel(context.Background())
	ch := make(chan runner.Event, 256)
	m.isRunning = true
	m.runCancel = cancel
	m.events = ch
	m.status = fmt.Sprintf("running %s", mode)
	m.now = time.Now()
	m.runMeta = runSession{
		Mode:      mode,
		Category:  m.currentCategory(),
		Selected:  m.selectedTool().Name,
		StartedAt: time.Now(),
	}

	req := runner.Request{
		Mode:          mode,
		SelectedTool:  m.selectedTool().Name,
		Category:      m.currentCategory(),
		Config:        m.cfg,
		ConfigPath:    m.configPath,
		ExecutionRoot: filepath.Clean(m.cfg.Workspace),
	}
	go runner.Run(ctx, req, ch)
	return tea.Batch(waitForRunnerEvent(ch), tickCmd())
}

func waitForRunnerEvent(ch <-chan runner.Event) tea.Cmd {
	if ch == nil {
		return nil
	}
	return func() tea.Msg {
		evt, ok := <-ch
		if !ok {
			return runCompletedMsg{}
		}
		return runnerEventMsg{Event: evt}
	}
}

func tickCmd() tea.Cmd {
	return tea.Tick(time.Second, func(t time.Time) tea.Msg {
		return tickMsg(t)
	})
}

func (m model) currentCategory() string {
	if len(m.categories) == 0 {
		return ""
	}
	if m.categoryIdx >= len(m.categories) {
		return m.categories[len(m.categories)-1]
	}
	return m.categories[m.categoryIdx]
}

func (m model) filteredToolIndices() []int {
	cat := m.currentCategory()
	indices := make([]int, 0)
	for i, tool := range m.cfg.Tools {
		if tool.Category == cat {
			indices = append(indices, i)
		}
	}
	return indices
}

func (m *model) selectedTool() *config.Tool {
	indices := m.filteredToolIndices()
	if len(indices) == 0 {
		return &m.cfg.Tools[0]
	}
	if m.toolIdx >= len(indices) {
		m.toolIdx = len(indices) - 1
	}
	return &m.cfg.Tools[indices[m.toolIdx]]
}

func (m model) fields() []fieldDef {
	return []fieldDef{
		{Name: "Enabled", Editable: false},
		{Name: "Description", Editable: true},
		{Name: "Mode", Editable: true},
		{Name: "Bin", Editable: true},
		{Name: "Args", Editable: true},
		{Name: "Shell", Editable: true},
		{Name: "Output", Editable: true},
		{Name: "DependsOn", Editable: true},
		{Name: "RequiresFiles", Editable: true},
	}
}

func (m *model) selectedField() fieldDef {
	fields := m.fields()
	if m.fieldIdx >= len(fields) {
		m.fieldIdx = len(fields) - 1
	}
	return fields[m.fieldIdx]
}

func (m model) fieldValue(fieldName string) string {
	tool := m.selectedTool()
	switch fieldName {
	case "Enabled":
		if tool.Enabled {
			return "true"
		}
		return "false"
	case "Description":
		return tool.Description
	case "Mode":
		return tool.Mode
	case "Bin":
		return tool.Bin
	case "Args":
		return strings.Join(tool.Args, " ")
	case "Shell":
		return tool.Shell
	case "Output":
		return tool.Output
	case "DependsOn":
		return strings.Join(tool.DependsOn, ", ")
	case "RequiresFiles":
		return strings.Join(tool.RequiresFiles, ", ")
	default:
		return ""
	}
}

func (m model) renderTools() string {
	styles := newStyles()
	indices := m.filteredToolIndices()
	if len(indices) == 0 {
		return styles.Muted.Render("No tools in this category")
	}
	var lines []string
	for pos, idx := range indices {
		tool := m.cfg.Tools[idx]
		marker := "  "
		style := styles.Item
		if pos == m.toolIdx {
			marker = "➜ "
			style = styles.SelectedItem
		}
		state := "off"
		if tool.Enabled {
			state = "on"
		}
		status := m.runNodes[tool.Name].State
		if status == "" {
			status = "idle"
		}
		lines = append(lines, style.Render(fmt.Sprintf("%s%s %s [%s] <%s>", marker, m.renderBootstrapBadge(tool.Name), tool.Name, state, status)))
	}
	return strings.Join(lines, "\n")
}

func (m model) renderFields() string {
	styles := newStyles()
	tool := m.selectedTool()
	header := styles.Header.Render(tool.Name) + "\n" + styles.Muted.Render(tool.Category)
	var body []string
	for i, field := range m.fields() {
		prefix := "  "
		style := styles.Item
		if i == m.fieldIdx && m.focus == focusFields {
			prefix = "➜ "
			style = styles.SelectedItem
		}
		body = append(body, style.Render(fmt.Sprintf("%s%s: %s", prefix, field.Name, truncate(m.fieldValue(field.Name), 72))))
	}
	if len(tool.DependsOn) > 0 {
		body = append(body, "", styles.Label.Render("Pipeline"), styles.Muted.Render("depends on: "+strings.Join(tool.DependsOn, ", ")))
	}
	if len(tool.RequiresFiles) > 0 {
		body = append(body, styles.Muted.Render("artifact gates: "+strings.Join(tool.RequiresFiles, ", ")))
	}
	body = append(body, "", styles.Label.Render("Bootstrap"), m.renderBootstrapDetails(tool.Name, 72))
	if status, ok := m.runNodes[tool.Name]; ok {
		body = append(body, "", styles.Label.Render("Latest run"), m.renderSelectedToolStatus(status))
	}
	if m.editing {
		body = append(body, "", styles.Label.Render("Editor"), m.editorInput.View())
	}
	return header + "\n\n" + strings.Join(body, "\n")
}

func (m model) renderSelectedToolStatus(status runner.ToolStatus) string {
	parts := []string{
		fmt.Sprintf("state: %s", status.State),
		fmt.Sprintf("exit: %d", status.ExitCode),
		fmt.Sprintf("artifacts: %d", status.ArtifactCount),
	}
	if d := m.nodeDuration(status); d != "" {
		parts = append(parts, "duration: "+d)
	}
	if status.OutputPath != "" {
		parts = append(parts, "output: "+status.OutputPath)
	}
	if status.Error != "" {
		parts = append(parts, "reason: "+status.Error)
	}
	return strings.Join(parts, "\n")
}

func (m model) renderRunGraph(width, height int) string {
	styles := newStyles()
	if len(m.runOrder) == 0 {
		return styles.Label.Render("Run graph") + "\n" + styles.Muted.Render("No run yet. Start a category, a selected tool, or the full pipeline.")
	}

	states := map[string]int{}
	for _, name := range m.runOrder {
		states[m.runNodes[name].State]++
	}
	summary := fmt.Sprintf("queued=%d waiting=%d running=%d finished=%d failed=%d skipped=%d",
		states["queued"], states["waiting"], states["running"], states["finished"], states["failed"], states["skipped"],
	)

	var lines []string
	lines = append(lines, styles.Label.Render("Run graph"))
	lines = append(lines, styles.Muted.Render(summary))

	grouped := make(map[string][]string)
	for _, name := range m.runOrder {
		grouped[m.runNodes[name].Category] = append(grouped[m.runNodes[name].Category], name)
	}
	cats := sortedKeys(grouped)
	for _, cat := range cats {
		lines = append(lines, "", styles.Label.Render(strings.ToUpper(cat)))
		for _, name := range grouped[cat] {
			node := m.runNodes[name]
			badge := m.renderStateBadge(node.State)
			meta := []string{}
			if dur := m.nodeDuration(node); dur != "" {
				meta = append(meta, dur)
			}
			if node.ExitCode != 0 || node.State == "finished" || node.State == "failed" {
				meta = append(meta, fmt.Sprintf("exit=%d", node.ExitCode))
			}
			if node.ArtifactCount > 0 || node.State == "finished" {
				meta = append(meta, fmt.Sprintf("artifacts=%d", node.ArtifactCount))
			}
			lines = append(lines, fmt.Sprintf("%s %s %s", badge, name, strings.Join(meta, "  ")))
			if len(node.DependsOn) > 0 {
				lines = append(lines, "  ├─ depends: "+strings.Join(node.DependsOn, ", "))
			}
			if len(node.RequiresFiles) > 0 {
				gates := shortenPaths(node.RequiresFiles, 2)
				lines = append(lines, "  ├─ gates: "+strings.Join(gates, ", "))
			}
			if node.OutputPath != "" {
				lines = append(lines, "  ├─ output: "+shortPath(node.OutputPath))
			}
			if node.Error != "" {
				lines = append(lines, "  └─ note: "+truncate(node.Error, max(24, width-12)))
			}
		}
	}

	if height < 1 {
		height = 1
	}
	if len(lines) > height {
		lines = lines[:height-1]
		lines = append(lines, styles.Muted.Render("... graph truncated to fit panel ..."))
	}
	return strings.Join(lines, "\n")
}

func (m model) renderArtifacts(width, height int) string {
	styles := newStyles()
	if len(m.artifacts) == 0 {
		return styles.Label.Render("Artifacts") + "\n" + styles.Muted.Render("No artifacts found in workspace yet.")
	}
	if m.artifactIdx >= len(m.artifacts) {
		m.artifactIdx = len(m.artifacts) - 1
	}
	selected := m.artifacts[m.artifactIdx]
	preview := readPreview(selected.Path, max(10, height-10))

	var lines []string
	lines = append(lines, styles.Label.Render("Artifacts"))
	lines = append(lines, styles.Muted.Render("Up/Down in center panel selects artifact. Latest files first."))
	for i, art := range firstNArtifacts(m.artifacts, 10) {
		prefix := "  "
		style := styles.Item
		if i == m.artifactIdx {
			prefix = "➜ "
			style = styles.SelectedItem
		}
		lines = append(lines, style.Render(fmt.Sprintf("%s%s (%s, %s)", prefix, art.RelPath, humanBytes(art.Size), art.ModTime.Format("2006-01-02 15:04:05"))))
	}
	lines = append(lines, "", styles.Label.Render("Preview"))
	lines = append(lines, styles.Muted.Render(fmt.Sprintf("Path: %s", selected.RelPath)))
	lines = append(lines, preview)
	return strings.Join(lines, "\n")
}

func (m model) renderHistory(width, height int) string {
	styles := newStyles()
	if len(m.historyRuns) == 0 {
		return styles.Label.Render("Run history") + "\n" + styles.Muted.Render("No stored runs yet.")
	}
	if m.historyIdx >= len(m.historyRuns) {
		m.historyIdx = len(m.historyRuns) - 1
	}
	selected := m.historyRuns[m.historyIdx]
	var lines []string
	lines = append(lines, styles.Label.Render("Run history"))
	lines = append(lines, styles.Muted.Render("Up/Down in center panel selects run summary."))
	for i, run := range firstNHistory(m.historyRuns, 8) {
		prefix := "  "
		style := styles.Item
		if i == m.historyIdx {
			prefix = "➜ "
			style = styles.SelectedItem
		}
		lines = append(lines, style.Render(fmt.Sprintf("%s%s %s target=%s f=%d fail=%d skip=%d",
			prefix,
			run.StartedAt.Format("2006-01-02 15:04:05"),
			strings.ToUpper(run.Mode),
			run.Target,
			run.Finished,
			run.Failed,
			run.Skipped,
		)))
	}
	lines = append(lines, "", styles.Label.Render("Selected run"))
	lines = append(lines,
		fmt.Sprintf("run id: %s", selected.RunID),
		fmt.Sprintf("target: %s", selected.Target),
		fmt.Sprintf("mode: %s", selected.Mode),
		fmt.Sprintf("category: %s", selected.Category),
		fmt.Sprintf("selected tool: %s", selected.SelectedTool),
		fmt.Sprintf("duration: %s", selected.Duration.Round(time.Second)),
	)
	lines = append(lines, "", styles.Label.Render("Nodes"))
	for _, node := range selected.Nodes {
		parts := []string{node.Tool, node.State}
		if node.ExitCode != 0 || node.State == "failed" {
			parts = append(parts, fmt.Sprintf("exit=%d", node.ExitCode))
		}
		if node.ArtifactCount > 0 || node.State == "finished" {
			parts = append(parts, fmt.Sprintf("artifacts=%d", node.ArtifactCount))
		}
		lines = append(lines, "- "+strings.Join(parts, " "))
		if node.Error != "" {
			lines = append(lines, "  "+truncate(node.Error, max(32, width-8)))
		}
	}
	if height < 1 {
		height = 1
	}
	if len(lines) > height {
		lines = lines[:height-1]
		lines = append(lines, styles.Muted.Render("... history truncated to fit panel ..."))
	}
	return strings.Join(lines, "\n")
}

func (m model) renderStateBadge(state string) string {
	styles := newStyles()
	label := strings.ToUpper(state)
	if label == "" {
		label = "IDLE"
	}
	switch state {
	case "running":
		return styles.BadgeStrong.Render(" " + label + " ")
	case "failed", "skipped":
		return styles.BadgeAlert.Render(" " + label + " ")
	case "finished":
		return styles.BadgeOK.Render(" " + label + " ")
	case "waiting":
		return styles.BadgeInfo.Render(" " + label + " ")
	default:
		return styles.Badge.Render(" " + label + " ")
	}
}

func (m model) nodeDuration(status runner.ToolStatus) string {
	if !status.StartedAt.IsZero() && status.FinishedAt.IsZero() {
		return m.now.Sub(status.StartedAt).Round(time.Second).String()
	}
	if status.Duration > 0 {
		return status.Duration.Round(time.Second).String()
	}
	return ""
}

func (m model) renderLogs(height int) string {
	if height < 1 {
		height = 1
	}
	start := 0
	if len(m.logs) > height {
		start = len(m.logs) - height
	}
	return strings.Join(m.logs[start:], "\n")
}

func (m model) renderHelp() string {
	styles := newStyles()
	text := []string{
		"Tab / Shift+Tab: move focus between target, tools, center, fields",
		"Left/Right: switch category when tool panel is focused",
		"Up/Down: move selection",
		"Space: toggle enabled on the Enabled field",
		"Enter: edit selected field",
		"Ctrl+S: save config",
		"g: graph/status view",
		"a: artifact browser",
		"H: run history",
		"b: bootstrap manager view",
		"B: refresh bootstrap checks",
		"?: help",
		"[: previous center view",
		"]: next center view",
		"r: run enabled tools in active category",
		"R: run all enabled tools",
		"x: run selected tool",
		"Esc while running: cancel run",
		"Dependency and artifact gate fields use comma-separated values",
	}
	return styles.Label.Render("Keys") + "\n" + strings.Join(text, "\n")
}

func (m model) renderBootstrap(width, height int) string {
	styles := newStyles()
	if m.bootstrapScanning {
		return styles.Label.Render("Bootstrap manager") + "\n" + styles.Muted.Render("Scanning PATH and probing tool versions...")
	}
	if len(m.bootstrapReport.Tools) == 0 {
		return styles.Label.Render("Bootstrap manager") + "\n" + styles.Muted.Render("No bootstrap data yet. Press B to refresh.")
	}
	indices := m.filteredToolIndices()
	var lines []string
	lines = append(lines, styles.Label.Render("Bootstrap manager"))
	lines = append(lines, styles.Muted.Render(m.bootstrapSummaryLine()))
	lines = append(lines, styles.Muted.Render("Missing badge = not runnable. PART badge = some shell deps found, some missing."))
	lines = append(lines, "", styles.Label.Render("Category readiness"))
	for _, idx := range indices {
		tool := m.cfg.Tools[idx]
		check, ok := m.bootstrapReport.Tools[tool.Name]
		if !ok {
			continue
		}
		lines = append(lines, fmt.Sprintf("%s %s — %s", m.renderBootstrapBadge(tool.Name), tool.Name, check.Summary))
	}
	lines = append(lines, "", styles.Label.Render("Selected tool"), m.renderBootstrapDetails(m.selectedTool().Name, max(28, width-6)))
	if height < 1 {
		height = 1
	}
	if len(lines) > height {
		lines = lines[:height-1]
		lines = append(lines, styles.Muted.Render("... bootstrap view truncated to fit panel ..."))
	}
	return strings.Join(lines, "\n")
}

func (m model) renderBootstrapBadge(toolName string) string {
	styles := newStyles()
	check, ok := m.bootstrapReport.Tools[toolName]
	if !ok {
		if m.bootstrapScanning {
			return styles.BadgeInfo.Render(" SCAN ")
		}
		return styles.Badge.Render(" ? ")
	}
	switch {
	case check.Builtin:
		return styles.BadgeInfo.Render(" BI ")
	case check.Missing:
		return styles.BadgeAlert.Render(" MISS ")
	case check.Partial:
		return styles.BadgeStrong.Render(" PART ")
	case check.Runnable:
		return styles.BadgeOK.Render(" OK ")
	default:
		return styles.Badge.Render(" ? ")
	}
}

func (m model) renderBootstrapDetails(toolName string, width int) string {
	styles := newStyles()
	check, ok := m.bootstrapReport.Tools[toolName]
	if !ok {
		if m.bootstrapScanning {
			return styles.Muted.Render("scan in progress...")
		}
		return styles.Muted.Render("no bootstrap data for selected tool")
	}
	parts := []string{check.Summary}
	if check.InstallHint != "" {
		parts = append(parts, "hint: "+truncate(check.InstallHint, width))
	}
	if len(check.Dependencies) == 0 {
		return strings.Join(parts, "\n")
	}
	parts = append(parts, "deps:")
	for _, dep := range check.Dependencies {
		state := "missing"
		if dep.Available {
			state = "ok"
		}
		line := fmt.Sprintf("- %s [%s]", dep.Name, state)
		if dep.Path != "" {
			line += " " + truncate(dep.Path, width-12)
		}
		parts = append(parts, line)
		if dep.Version != "" {
			parts = append(parts, "  ver: "+truncate(dep.Version, width-8))
		}
		if !dep.Available && dep.InstallHint != "" {
			parts = append(parts, "  fix: "+truncate(dep.InstallHint, width-8))
		}
	}
	return strings.Join(parts, "\n")
}

func (m model) bootstrapSummaryLine() string {
	if m.bootstrapScanning {
		return "scanning toolchain..."
	}
	s := m.bootstrapReport.Summary
	if s.Total == 0 {
		return "not scanned yet"
	}
	return fmt.Sprintf("runnable=%d missing=%d partial=%d builtin=%d enabled=%d total=%d", s.Runnable, s.Missing, s.Partial, s.Builtin, s.Enabled, s.Total)
}

func scanBootstrapCmd(cfg *config.App) tea.Cmd {
	return func() tea.Msg {
		return bootstrapScannedMsg{Report: bootstrap.Scan(cfg)}
	}
}

func (m *model) trimLogs() {
	if len(m.logs) > 600 {
		m.logs = m.logs[len(m.logs)-600:]
	}
}

func (m *model) refreshArtifacts() {
	root := filepath.Clean(m.cfg.Workspace)
	var items []artifactEntry
	_ = filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil || d == nil || d.IsDir() {
			return nil
		}
		if strings.HasPrefix(filepath.Base(path), ".") {
			return nil
		}
		info, err := d.Info()
		if err != nil {
			return nil
		}
		rel, _ := filepath.Rel(root, path)
		items = append(items, artifactEntry{
			Path:    path,
			RelPath: rel,
			Size:    info.Size(),
			ModTime: info.ModTime(),
		})
		return nil
	})
	sort.Slice(items, func(i, j int) bool {
		if items[i].ModTime.Equal(items[j].ModTime) {
			return items[i].RelPath < items[j].RelPath
		}
		return items[i].ModTime.After(items[j].ModTime)
	})
	m.artifacts = items
	if m.artifactIdx >= len(m.artifacts) && len(m.artifacts) > 0 {
		m.artifactIdx = len(m.artifacts) - 1
	}
	if len(m.artifacts) == 0 {
		m.artifactIdx = 0
	}
}

func (m *model) refreshHistory() {
	runs, err := history.LoadRecent(filepath.Join(m.cfg.Workspace, "history"), 50)
	if err != nil {
		m.logs = append(m.logs, "[history] load failed: "+err.Error())
		m.trimLogs()
		return
	}
	m.historyRuns = runs
	if m.historyIdx >= len(m.historyRuns) && len(m.historyRuns) > 0 {
		m.historyIdx = len(m.historyRuns) - 1
	}
	if len(m.historyRuns) == 0 {
		m.historyIdx = 0
	}
}

func (m *model) persistCurrentRun() {
	if m.runMeta.StartedAt.IsZero() || len(m.runOrder) == 0 {
		return
	}
	summary := history.RunSummary{
		RunID:        m.runMeta.StartedAt.UTC().Format("20060102T150405Z"),
		Target:       strings.TrimSpace(m.targetInput.Value()),
		Mode:         string(m.runMeta.Mode),
		Category:     m.runMeta.Category,
		SelectedTool: m.runMeta.Selected,
		StartedAt:    m.runMeta.StartedAt,
		FinishedAt:   time.Now(),
	}
	summary.Duration = summary.FinishedAt.Sub(summary.StartedAt)
	for _, name := range m.runOrder {
		node := m.runNodes[name]
		summary.Nodes = append(summary.Nodes, history.NodeSummary{
			Tool:          node.Tool,
			Category:      node.Category,
			State:         node.State,
			DependsOn:     append([]string(nil), node.DependsOn...),
			RequiresFiles: append([]string(nil), node.RequiresFiles...),
			StartedAt:     node.StartedAt,
			FinishedAt:    node.FinishedAt,
			Duration:      node.Duration,
			ExitCode:      node.ExitCode,
			OutputPath:    node.OutputPath,
			ArtifactCount: node.ArtifactCount,
			Error:         node.Error,
		})
		switch node.State {
		case "finished":
			summary.Finished++
		case "failed":
			summary.Failed++
		case "skipped":
			summary.Skipped++
		}
	}
	path, err := history.SaveSummary(filepath.Join(m.cfg.Workspace, "history"), summary)
	if err != nil {
		m.logs = append(m.logs, "[history] save failed: "+err.Error())
	} else {
		m.logs = append(m.logs, "[history] saved run summary to "+path)
	}
	m.trimLogs()
	m.runMeta = runSession{}
}

type styles struct {
	Header         lipgloss.Style
	Panel          lipgloss.Style
	LogPanel       lipgloss.Style
	Status         lipgloss.Style
	Item           lipgloss.Style
	SelectedItem   lipgloss.Style
	Label          lipgloss.Style
	Muted          lipgloss.Style
	Category       lipgloss.Style
	ActiveCategory lipgloss.Style
	Badge          lipgloss.Style
	BadgeStrong    lipgloss.Style
	BadgeInfo      lipgloss.Style
	BadgeOK        lipgloss.Style
	BadgeAlert     lipgloss.Style
}

func newStyles() styles {
	return styles{
		Header:         lipgloss.NewStyle().Bold(true).Padding(0, 1),
		Panel:          lipgloss.NewStyle().Border(lipgloss.RoundedBorder()).Padding(1).MarginRight(1),
		LogPanel:       lipgloss.NewStyle().Border(lipgloss.RoundedBorder()).Padding(1).MarginTop(1),
		Status:         lipgloss.NewStyle().Border(lipgloss.NormalBorder()).Padding(0, 1).MarginTop(1),
		Item:           lipgloss.NewStyle(),
		SelectedItem:   lipgloss.NewStyle().Bold(true),
		Label:          lipgloss.NewStyle().Bold(true),
		Muted:          lipgloss.NewStyle().Faint(true),
		Category:       lipgloss.NewStyle().Border(lipgloss.NormalBorder()).Padding(0, 1).MarginRight(1),
		ActiveCategory: lipgloss.NewStyle().Border(lipgloss.DoubleBorder()).Bold(true).Padding(0, 1).MarginRight(1),
		Badge:          lipgloss.NewStyle().Border(lipgloss.NormalBorder()).Bold(true),
		BadgeStrong:    lipgloss.NewStyle().Border(lipgloss.DoubleBorder()).Bold(true),
		BadgeInfo:      lipgloss.NewStyle().Border(lipgloss.RoundedBorder()).Bold(true),
		BadgeOK:        lipgloss.NewStyle().Border(lipgloss.RoundedBorder()).Bold(true),
		BadgeAlert:     lipgloss.NewStyle().Border(lipgloss.ThickBorder()).Bold(true),
	}
}

func collectCategories(tools []config.Tool) []string {
	seen := map[string]struct{}{}
	var cats []string
	for _, tool := range tools {
		cat := strings.TrimSpace(tool.Category)
		if cat == "" {
			cat = "uncategorized"
		}
		if _, ok := seen[cat]; ok {
			continue
		}
		seen[cat] = struct{}{}
		cats = append(cats, cat)
	}
	preferred := []string{"subdomains", "dns", "probe", "urls", "params", "content", "js", "secrets", "vulns", "takeover", "screenshots", "intel", "api"}
	order := map[string]int{}
	for i, name := range preferred {
		order[name] = i
	}
	sort.Slice(cats, func(i, j int) bool {
		oi, okI := order[cats[i]]
		oj, okJ := order[cats[j]]
		switch {
		case okI && okJ:
			return oi < oj
		case okI:
			return true
		case okJ:
			return false
		default:
			return cats[i] < cats[j]
		}
	})
	return cats
}

func readPreview(path string, maxLines int) string {
	if maxLines < 1 {
		maxLines = 1
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return "preview failed: " + err.Error()
	}
	if bytes.IndexByte(b, 0) >= 0 {
		return "binary-looking file, preview skipped"
	}
	lines := strings.Split(string(b), "\n")
	if len(lines) > maxLines {
		lines = lines[:maxLines]
		lines = append(lines, "... preview truncated ...")
	}
	return strings.Join(lines, "\n")
}

func firstNArtifacts(in []artifactEntry, n int) []artifactEntry {
	if len(in) <= n {
		return in
	}
	return in[:n]
}

func firstNHistory(in []history.RunSummary, n int) []history.RunSummary {
	if len(in) <= n {
		return in
	}
	return in[:n]
}

func humanBytes(size int64) string {
	const unit = 1024
	if size < unit {
		return fmt.Sprintf("%d B", size)
	}
	div, exp := int64(unit), 0
	for n := size / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %ciB", float64(size)/float64(div), "KMGTPE"[exp])
}

func splitArgs(input string) []string {
	parts := strings.Fields(strings.TrimSpace(input))
	if len(parts) == 0 {
		return nil
	}
	return parts
}

func splitCSV(input string) []string {
	if strings.TrimSpace(input) == "" {
		return nil
	}
	parts := strings.Split(input, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		out = append(out, part)
	}
	if len(out) == 0 {
		return nil
	}
	return out
}

func truncate(s string, maxLen int) string {
	if maxLen < 4 {
		return s
	}
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}

func shortPath(path string) string {
	path = filepath.Clean(path)
	parts := strings.Split(path, string(os.PathSeparator))
	if len(parts) <= 3 {
		return path
	}
	return filepath.Join(parts[len(parts)-3:]...)
}

func shortenPaths(paths []string, keep int) []string {
	out := make([]string, 0, len(paths))
	for _, path := range paths {
		cleaned := filepath.Clean(path)
		parts := strings.Split(cleaned, string(os.PathSeparator))
		if len(parts) > keep {
			cleaned = filepath.Join(parts[len(parts)-keep:]...)
		}
		out = append(out, cleaned)
	}
	return out
}

func sortedKeys[V any](m map[string]V) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
