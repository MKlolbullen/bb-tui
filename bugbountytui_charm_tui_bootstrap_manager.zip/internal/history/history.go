package history

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type NodeSummary struct {
	Tool          string        `json:"tool"`
	Category      string        `json:"category"`
	State         string        `json:"state"`
	DependsOn     []string      `json:"depends_on,omitempty"`
	RequiresFiles []string      `json:"requires_files,omitempty"`
	StartedAt     time.Time     `json:"started_at,omitempty"`
	FinishedAt    time.Time     `json:"finished_at,omitempty"`
	Duration      time.Duration `json:"duration,omitempty"`
	ExitCode      int           `json:"exit_code,omitempty"`
	OutputPath    string        `json:"output_path,omitempty"`
	ArtifactCount int           `json:"artifact_count,omitempty"`
	Error         string        `json:"error,omitempty"`
}

type RunSummary struct {
	RunID        string        `json:"run_id"`
	Target       string        `json:"target"`
	Mode         string        `json:"mode"`
	Category     string        `json:"category,omitempty"`
	SelectedTool string        `json:"selected_tool,omitempty"`
	StartedAt    time.Time     `json:"started_at"`
	FinishedAt   time.Time     `json:"finished_at"`
	Duration     time.Duration `json:"duration"`
	Finished     int           `json:"finished"`
	Failed       int           `json:"failed"`
	Skipped      int           `json:"skipped"`
	Nodes        []NodeSummary `json:"nodes"`
}

func SaveSummary(dir string, summary RunSummary) (string, error) {
	if strings.TrimSpace(summary.RunID) == "" {
		summary.RunID = time.Now().UTC().Format("20060102T150405Z")
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", fmt.Errorf("create history dir: %w", err)
	}
	path := filepath.Join(dir, fmt.Sprintf("run-%s.json", summary.RunID))
	data, err := json.MarshalIndent(summary, "", "  ")
	if err != nil {
		return "", fmt.Errorf("marshal history summary: %w", err)
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		return "", fmt.Errorf("write history summary: %w", err)
	}
	return path, nil
}

func LoadRecent(dir string, limit int) ([]RunSummary, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("read history dir: %w", err)
	}

	type item struct {
		path string
		name string
		mod  time.Time
	}
	items := make([]item, 0, len(entries))
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(strings.ToLower(entry.Name()), ".json") {
			continue
		}
		info, err := entry.Info()
		if err != nil {
			continue
		}
		items = append(items, item{
			path: filepath.Join(dir, entry.Name()),
			name: entry.Name(),
			mod:  info.ModTime(),
		})
	}

	sort.Slice(items, func(i, j int) bool {
		if items[i].mod.Equal(items[j].mod) {
			return items[i].name > items[j].name
		}
		return items[i].mod.After(items[j].mod)
	})

	if limit > 0 && len(items) > limit {
		items = items[:limit]
	}

	out := make([]RunSummary, 0, len(items))
	for _, it := range items {
		b, err := os.ReadFile(it.path)
		if err != nil {
			continue
		}
		var summary RunSummary
		if err := json.Unmarshal(b, &summary); err != nil {
			continue
		}
		out = append(out, summary)
	}
	return out, nil
}
