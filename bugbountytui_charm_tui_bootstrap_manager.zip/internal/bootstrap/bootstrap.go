package bootstrap

import (
	"bytes"
	"context"
	"fmt"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"bugbountytui/internal/config"
)

type DependencyCheck struct {
	Name        string
	Path        string
	Version     string
	Available   bool
	InstallHint string
}

type ToolCheck struct {
	ToolName     string
	Category     string
	Mode         string
	Enabled      bool
	Builtin      bool
	Runnable     bool
	Missing      bool
	Partial      bool
	Dependencies []DependencyCheck
	MissingDeps  []string
	Summary      string
	InstallHint  string
}

type Summary struct {
	Total    int
	Enabled  int
	Runnable int
	Missing  int
	Partial  int
	Builtin  int
}

type Report struct {
	CheckedAt time.Time
	Tools     map[string]ToolCheck
	Order     []string
	Summary   Summary
}

func Scan(cfg *config.App) Report {
	report := Report{
		CheckedAt: time.Now(),
		Tools:     make(map[string]ToolCheck, len(cfg.Tools)),
		Order:     make([]string, 0, len(cfg.Tools)),
	}
	cache := map[string]DependencyCheck{}
	for _, tool := range cfg.Tools {
		check := checkTool(tool, cache, true)
		report.Tools[tool.Name] = check
		report.Order = append(report.Order, tool.Name)
		report.Summary.Total++
		if tool.Enabled {
			report.Summary.Enabled++
		}
		if check.Builtin {
			report.Summary.Builtin++
		}
		if check.Missing {
			report.Summary.Missing++
		} else if check.Partial {
			report.Summary.Partial++
		} else if check.Runnable {
			report.Summary.Runnable++
		}
	}
	return report
}

func QuickCheck(tool config.Tool) ToolCheck {
	return checkTool(tool, map[string]DependencyCheck{}, false)
}

func MissingReason(tool config.Tool) (string, bool) {
	check := QuickCheck(tool)
	if check.Builtin || check.Runnable {
		return "", false
	}
	if len(check.MissingDeps) == 0 {
		return "tool preflight failed: unresolved runtime dependencies", true
	}
	return fmt.Sprintf("tool unavailable: missing %s", strings.Join(check.MissingDeps, ", ")), true
}

func checkTool(tool config.Tool, cache map[string]DependencyCheck, withVersion bool) ToolCheck {
	check := ToolCheck{
		ToolName: tool.Name,
		Category: tool.Category,
		Mode:     tool.Mode,
		Enabled:  tool.Enabled,
	}
	if tool.Mode == "builtin-crtsh" {
		check.Builtin = true
		check.Runnable = true
		check.Summary = "builtin workflow step"
		check.InstallHint = "No install needed. This step is built into the TUI."
		return check
	}

	deps := DependencyNames(tool)
	if len(deps) == 0 {
		check.Runnable = true
		check.Summary = "no external dependency inferred"
		check.InstallHint = InstallHint(tool.Name, "")
		return check
	}

	for _, dep := range deps {
		depCheck, ok := cache[dep]
		if !ok {
			depCheck = checkDependency(dep, withVersion)
			cache[dep] = depCheck
		}
		check.Dependencies = append(check.Dependencies, depCheck)
		if !depCheck.Available {
			check.MissingDeps = append(check.MissingDeps, depCheck.Name)
		}
	}

	availableCount := 0
	for _, dep := range check.Dependencies {
		if dep.Available {
			availableCount++
		}
	}

	switch {
	case len(check.MissingDeps) == 0:
		check.Runnable = true
		check.Summary = fmt.Sprintf("ready: %d/%d runtime deps found", availableCount, len(check.Dependencies))
	case availableCount == 0:
		check.Missing = true
		check.Summary = fmt.Sprintf("missing: %s", strings.Join(check.MissingDeps, ", "))
	default:
		check.Partial = true
		check.Summary = fmt.Sprintf("partial: %d/%d found, missing %s", availableCount, len(check.Dependencies), strings.Join(check.MissingDeps, ", "))
	}

	check.InstallHint = InstallHint(tool.Name, firstMissing(check.MissingDeps))
	return check
}

func checkDependency(dep string, withVersion bool) DependencyCheck {
	check := DependencyCheck{Name: dep, InstallHint: InstallHint(dep, dep)}
	path, err := exec.LookPath(dep)
	if err != nil {
		return check
	}
	check.Path = path
	check.Available = true
	if withVersion {
		check.Version = detectVersion(dep, path)
	}
	return check
}

func DependencyNames(tool config.Tool) []string {
	seen := map[string]struct{}{}
	add := func(dep string, out *[]string) {
		dep = normalizeDepName(dep)
		if dep == "" {
			return
		}
		if _, ok := seen[dep]; ok {
			return
		}
		seen[dep] = struct{}{}
		*out = append(*out, dep)
	}

	var deps []string
	switch tool.Mode {
	case "exec":
		add(tool.Bin, &deps)
	case "shell":
		for _, dep := range inferShellDependencies(tool.Shell) {
			add(dep, &deps)
		}
	}
	return deps
}

func inferShellDependencies(shell string) []string {
	replacer := strings.NewReplacer("&&", "\n", "||", "\n", "|", "\n", ";", "\n")
	segments := strings.Split(replacer.Replace(shell), "\n")
	seen := map[string]struct{}{}
	var deps []string
	for _, seg := range segments {
		tokens := strings.Fields(strings.TrimSpace(seg))
		for _, tok := range tokens {
			candidate := normalizeDepName(tok)
			if candidate == "" {
				continue
			}
			if _, ok := seen[candidate]; ok {
				break
			}
			seen[candidate] = struct{}{}
			deps = append(deps, candidate)
			break
		}
	}
	return deps
}

func normalizeDepName(token string) string {
	token = strings.TrimSpace(token)
	token = strings.Trim(token, "'\"`(){}[]")
	if token == "" {
		return ""
	}
	if strings.HasPrefix(token, "{{") || strings.HasPrefix(token, "$") {
		return ""
	}
	if strings.Contains(token, "=") && !strings.Contains(token, "/") && !strings.HasPrefix(token, ".") {
		return ""
	}
	if strings.HasPrefix(token, "<") || strings.HasPrefix(token, ">") {
		return ""
	}
	if idx := strings.Index(token, "="); idx > 0 && !strings.Contains(token[:idx], "/") {
		return ""
	}
	base := filepath.Base(token)
	base = strings.TrimSpace(base)
	if base == "." || base == "/" {
		return ""
	}
	if isShellNoise(base) {
		return ""
	}
	return base
}

func isShellNoise(tok string) bool {
	_, ok := shellNoise[tok]
	return ok
}

var shellNoise = map[string]struct{}{
	"while": {}, "do": {}, "done": {}, "if": {}, "then": {}, "else": {}, "elif": {}, "fi": {},
	"for": {}, "in": {}, "case": {}, "esac": {}, "function": {}, "{": {}, "}": {},
	"read": {}, "echo": {}, "printf": {}, "test": {}, "[": {}, "]": {},
	"cat": {}, "sort": {}, "uniq": {}, "grep": {}, "egrep": {}, "fgrep": {}, "sed": {}, "awk": {},
	"tr": {}, "tee": {}, "cut": {}, "paste": {}, "head": {}, "tail": {}, "wc": {}, "xargs": {},
	"mkdir": {}, "rm": {}, "cp": {}, "mv": {}, "find": {}, "pwd": {}, "cd": {},
	"bash": {}, "sh": {}, "env": {}, "sudo": {},
}

func detectVersion(dep, path string) string {
	strategies := versionArgs(dep)
	for _, args := range strategies {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		cmd := exec.CommandContext(ctx, path, args...)
		out, err := cmd.CombinedOutput()
		cancel()
		if ctx.Err() == context.DeadlineExceeded {
			continue
		}
		line := firstUsefulLine(out)
		if line == "" {
			if err == nil {
				return "present"
			}
			continue
		}
		return truncateLine(line, 96)
	}
	return "present"
}

func versionArgs(dep string) [][]string {
	if args, ok := versionFlagHints[dep]; ok {
		return args
	}
	return [][]string{{"--version"}, {"version"}, {"-version"}, {"-V"}, {"-v"}}
}

var versionFlagHints = map[string][][]string{
	"assetfinder": {{"-h"}},
	"amass":       {{"-version"}, {"version"}},
	"chaos":       {{"-version"}, {"version"}},
	"subfinder":   {{"-version"}, {"version"}},
	"httpx":       {{"-version"}, {"version"}},
	"dnsx":        {{"-version"}, {"version"}},
	"naabu":       {{"-version"}, {"version"}},
	"katana":      {{"-version"}, {"version"}},
	"nuclei":      {{"-version"}, {"version"}},
	"tlsx":        {{"-version"}, {"version"}},
	"uncover":     {{"-version"}, {"version"}},
	"jaeles":      {{"version"}, {"-version"}},
	"kr":          {{"-h"}},
	"ffuf":        {{"-V"}, {"-h"}},
	"feroxbuster": {{"--version"}},
	"gau":         {{"--version"}, {"-h"}},
	"waybackurls": {{"-h"}},
	"paramspider": {{"-h"}},
	"arjun":       {{"-h"}},
	"subjs":       {{"-h"}},
	"dalfox":      {{"version"}, {"-h"}},
	"sqlmap":      {{"--version"}},
	"xsstrike":    {{"-h"}},
	"python3":     {{"--version"}},
}

func firstUsefulLine(out []byte) string {
	for _, line := range bytes.Split(out, []byte("\n")) {
		trimmed := strings.TrimSpace(string(line))
		if trimmed == "" {
			continue
		}
		return trimmed
	}
	return ""
}

func InstallHint(toolOrDep, fallback string) string {
	key := strings.TrimSpace(toolOrDep)
	if hint, ok := installHints[key]; ok {
		return hint
	}
	if pdTools[key] {
		return fmt.Sprintf("Install with ProjectDiscovery's tool manager: pdtm -i %s", key)
	}
	if fallback != "" {
		return fmt.Sprintf("Install %s and make sure it is in PATH.", fallback)
	}
	return "Install the missing runtime dependency and make sure it is in PATH."
}

var pdTools = map[string]bool{
	"subfinder": true,
	"chaos":     true,
	"dnsx":      true,
	"cdncheck":  true,
	"httpx":     true,
	"naabu":     true,
	"tlsx":      true,
	"katana":    true,
	"nuclei":    true,
	"uncover":   true,
}

var installHints = map[string]string{
	"crt.sh":            "No install needed. This step is built into the TUI.",
	"assetfinder":       "Install from the upstream release or build it from source and add it to PATH.",
	"jaeles":            "Install with Go: go install github.com/jaeles-project/jaeles@latest",
	"kr":                "Download a kiterunner release or build from source with make build, then symlink dist/kr into PATH.",
	"kiterunner":        "Download a kiterunner release or build from source with make build, then symlink dist/kr into PATH.",
	"python3":           "Install Python 3 and make sure python3 is in PATH.",
	"ffuf":              "Install ffuf and make sure the binary is in PATH.",
	"feroxbuster":       "Install feroxbuster and make sure the binary is in PATH.",
	"dirsearch":         "Install dirsearch and make sure the dirsearch launcher is in PATH.",
	"amass":             "Install OWASP Amass and make sure amass is in PATH.",
	"findomain":         "Install findomain and make sure the binary is in PATH.",
	"github-subdomains": "Install github-subdomains and make sure the binary is in PATH.",
	"shuffledns":        "Install shuffledns and make sure the binary is in PATH.",
	"paramspider":       "Install ParamSpider and make sure the launcher is in PATH.",
	"gau":               "Install gau and make sure the binary is in PATH.",
	"waybackurls":       "Install waybackurls and make sure the binary is in PATH.",
	"subjs":             "Install subjs and make sure the binary is in PATH.",
	"cariddi":           "Install cariddi and make sure the binary is in PATH.",
	"dalfox":            "Install dalfox and make sure the binary is in PATH.",
	"xsstrike":          "Install XSStrike and make sure the launcher is in PATH.",
	"sqlmap":            "Install sqlmap and make sure the launcher is in PATH.",
}

func firstMissing(missing []string) string {
	if len(missing) == 0 {
		return ""
	}
	copyMissing := append([]string(nil), missing...)
	sort.Strings(copyMissing)
	return copyMissing[0]
}

func truncateLine(s string, maxLen int) string {
	if maxLen < 4 || len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
